/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FolderLock,
  ShieldAlert,
  AlertOctagon,
  Skull,
  TrendingUp,
  ArrowRight,
  ShieldCheck,
  Zap,
  CheckCircle,
  ExternalLink,
  Search,
  BookOpen
} from 'lucide-react';
import { Asset, Risk, Incident } from '../types';

interface DashboardHomeProps {
  assets: Asset[];
  risks: Risk[];
  incidents: Incident[];
  onNavigate: (view: string) => void;
  onUpdateRiskStatus?: (riskId: string, status: 'Identified' | 'Mitigated' | 'Monitoring') => void;
}

export default function DashboardHome({
  assets,
  risks,
  incidents,
  onNavigate,
  onUpdateRiskStatus
}: DashboardHomeProps) {
  const [hoveredPieIndex, setHoveredPieIndex] = useState<number | null>(null);
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);
  const [selectedRiskFilter, setSelectedRiskFilter] = useState<string | null>(null);

  // Stats calculation
  const totalAssets = assets.length;
  const totalRisks = risks.length;
  const criticalRisksCount = risks.filter((r) => r.level === 'Critical').length;
  const activeIncidents = incidents.filter((i) => i.status !== 'Closed').length;

  // Pie chart calculation (Risk Level Distribution)
  const riskLevels = ['Low', 'Medium', 'High', 'Critical'] as const;
  const riskColorMap = {
    Low: '#10b981',      // Emerald 500
    Medium: '#eab308',   // Yellow 500
    High: '#f97316',     // Orange 500
    Critical: '#ef4444'  // Red 500
  };

  const riskCounts = riskLevels.reduce((acc, level) => {
    acc[level] = risks.filter((r) => r.level === level).length;
    return acc;
  }, {} as Record<string, number>);

  const totalLevelRisks = totalRisks || 1;
  const pieData = riskLevels.map((level) => ({
    name: level,
    count: riskCounts[level],
    percentage: Math.round((riskCounts[level] / totalLevelRisks) * 100),
    color: riskColorMap[level]
  }));

  // Bar chart calculation (Risks by Asset Type)
  const assetTypes = ['Software', 'Network', 'Data', 'Hardware', 'Physical'] as const;
  const typeColorMap = {
    Software: '#3b82f6', // Blue
    Network: '#8b5cf6',  // Purple
    Data: '#ec4899',     // Pink
    Hardware: '#f59e0b', // Amber
    Physical: '#64748b'  // Slate
  };

  const risksByType = assetTypes.map((type) => {
    // Find assets of this type
    const assetIdsOfType = assets.filter((a) => a.type === type).map((a) => a.id);
    // Find risks associated with those assets
    const count = risks.filter((r) => assetIdsOfType.includes(r.assetId)).length;
    return {
      type,
      count,
      color: typeColorMap[type]
    };
  });

  const maxBarCount = Math.max(...risksByType.map((r) => r.count), 1);

  // Critical Alerts list (Risks that are high or critical)
  const criticalAlerts = risks.filter((r) => r.level === 'Critical' || r.level === 'High');

  // Helper to map assetId to Asset Name
  const getAssetName = (id: string) => {
    const asset = assets.find((a) => a.id === id);
    return asset ? asset.name : 'Unknown Asset';
  };

  // Helper to draw SVG Pie Slice
  // Formula for pie slices: center (100, 100), radius 75
  let accumulatedAngle = 0;

  return (
    <div className="space-y-6 animate-in fade-in duration-350">
      {/* Upper banner section */}
      <div className="p-6 bg-slate-900 text-white rounded-2xl shadow-xl border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
        {/* Abstract background graphics for college theme */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial-gradient from-blue-500/10 to-transparent pointer-events-none" />
        <div className="z-10 max-w-2xl">
          <div className="flex items-center space-x-2 text-blue-400 mb-1">
            <BookOpen className="h-4 w-4" />
            <span className="text-xs uppercase tracking-wider font-mono font-bold">Academic Cybersecurity Directorate / المديرية الأكاديمية للأمن السيبراني</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight">
            Security & Compliance Risk Hub / مركز مخاطر الأمن والامتثال
          </h2>
          <p className="text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
            Technical College Ahad Rafidah risk profiling service is monitoring Active Networks, Databases, Registrar Gateways, and Campus Information Assets. / تقوم خدمة تحديد المخاطر بالكلية التقنية بأحد رفيدة بمراقبة الشبكات النشطة وقواعد البيانات وبوابات التسجيل وأصول معلومات الحرم الجامعي.
          </p>
        </div>
        <div className="flex gap-3 shrink-0 z-10">
          <button
            onClick={() => onNavigate('incident')}
            className="px-4 py-2 bg-rose-600/15 text-rose-300 border border-rose-500/20 rounded-xl hover:bg-rose-600/25 transition-all text-xs font-semibold cursor-pointer"
          >
            Declare Outage/Incident / الإبلاغ عن حادثة أو انقطاع
          </button>
          <button
            onClick={() => onNavigate('risk')}
            className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-xl hover:bg-blue-700 shadow-md shadow-blue-500/20 active:translate-y-0.5 transition-all text-xs cursor-pointer"
          >
            Assess New Applet Risk / تقييم مخاطر تطبيق جديد
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Assets */}
        <div
          onClick={() => onNavigate('asset')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md cursor-pointer group transition-all duration-300"
        >
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Total College Assets / إجمالي الأصول
              </span>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none pt-1">
                {totalAssets}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400 group-hover:scale-110 transition-transform">
              <FolderLock className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center text-xs text-blue-600 dark:text-blue-400 font-semibold">
            <span>Manage Academic Inventory / إدارة المخزون الأكاديمي</span>
            <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Total Risks */}
        <div
          onClick={() => onNavigate('risk')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md cursor-pointer group transition-all duration-300"
        >
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Active Threat Vectors / مسارات التهديد النشطة
              </span>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none pt-1">
                {totalRisks}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 dark:bg-slate-800 dark:text-amber-400 group-hover:scale-110 transition-transform">
              <ShieldAlert className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center text-xs text-amber-600 dark:text-amber-400 font-semibold">
            <span>Evaluate Threat Matrix / تقييم مصفوفة التهديدات</span>
            <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Critical Risks */}
        <div
          onClick={() => {
            setSelectedRiskFilter('Critical');
            const el = document.getElementById('critical-alerts-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md cursor-pointer group transition-all duration-300"
        >
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Critical Risks Level / مستوى المخاطر الحرجة
              </span>
              <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 font-mono leading-none pt-1">
                {criticalRisksCount}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-rose-50 text-rose-600 dark:bg-slate-800 dark:text-rose-400 group-hover:scale-110 transition-transform">
              <AlertOctagon className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center text-xs text-rose-600 dark:text-rose-400 font-semibold">
            <span>Critical Hotspots Identified / تشخيص نقاط الضعف الحرجة</span>
            <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Incidents */}
        <div
          onClick={() => onNavigate('incident')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 hover:shadow-md cursor-pointer group transition-all duration-300"
        >
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">
                Unresolved Outages / انقطاعات غير محلولة
              </span>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono leading-none pt-1">
                {activeIncidents}
              </p>
            </div>
            <div className="p-2.5 rounded-xl bg-violet-50 text-violet-600 dark:bg-slate-800 dark:text-violet-400 group-hover:scale-110 transition-transform">
              <Skull className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center text-xs text-violet-600 dark:text-violet-400 font-semibold">
            <span>Process Incident Log / سجل معالجة الحوادث</span>
            <ArrowRight className="h-3 w-3 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Pie Chart: Risk Distribution */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 lg:col-span-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
                Risk Distribution Level / مستوى توزيع المخاطر
              </h3>
              <span className="text-[10px] font-mono text-slate-400 uppercase">
                Interactive Pie Segments / شرائح فطيرة تفاعلية
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Current security threat landscape distribution by severity mapping. / توزيع المخاطر الأمنية الحالية حسب شدتها.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-around my-6 gap-6">
            {/* SVG PIE CHART */}
            <div className="relative w-40 h-40">
              <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
                {totalRisks === 0 ? (
                  <circle cx="100" cy="100" r="75" fill="#e2e8f0" />
                ) : (
                  pieData.map((slice, index) => {
                    if (slice.count === 0) return null;
                    const angle = (slice.count / totalRisks) * 360;
                    const angleStart = accumulatedAngle;
                    accumulatedAngle += angle;

                    // Convert to coordinates
                    const x1 = 100 + 75 * Math.cos((angleStart * Math.PI) / 180);
                    const y1 = 100 + 75 * Math.sin((angleStart * Math.PI) / 180);
                    const x2 = 100 + 75 * Math.cos(((angleStart + angle) * Math.PI) / 180);
                    const y2 = 100 + 75 * Math.sin(((angleStart + angle) * Math.PI) / 180);

                    const largeArcFlag = angle > 180 ? 1 : 0;
                    const isHovered = hoveredPieIndex === index;

                    return (
                      <path
                        key={slice.name}
                        d={`M 100 100 L ${x1} ${y1} A 75 75 0 ${largeArcFlag} 1 ${x2} ${y2} Z`}
                        fill={slice.color}
                        className="transition-all duration-300 cursor-pointer hover:opacity-90 hover:stroke-white hover:stroke-2"
                        style={{
                          transform: isHovered ? 'scale(1.04) translate(-2px, -2px)' : 'none',
                          transformOrigin: 'center'
                        }}
                        onMouseEnter={() => setHoveredPieIndex(index)}
                        onMouseLeave={() => setHoveredPieIndex(null)}
                        onClick={() => setSelectedRiskFilter(slice.name)}
                      />
                    );
                  })
                )}
                {/* Center Cutout for Donut look */}
                <circle cx="100" cy="100" r="45" className="fill-white dark:fill-slate-900" />
              </svg>
              {/* Inner Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-bold font-mono text-slate-800 dark:text-white">
                  {totalRisks}
                </span>
                <span className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">
                  Threats / مستجدات المخاطر
                </span>
              </div>
            </div>

            {/* Labels List */}
            <div className="space-y-2 flex-grow sm:max-w-[160px]">
              {pieData.map((slice, index) => (
                <div
                  key={slice.name}
                  onClick={() => setSelectedRiskFilter(slice.name === selectedRiskFilter ? null : slice.name)}
                  onMouseEnter={() => setHoveredPieIndex(index)}
                  onMouseLeave={() => setHoveredPieIndex(null)}
                  className={`p-1.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                    selectedRiskFilter === slice.name
                      ? 'bg-slate-100 dark:bg-slate-800 border-slate-300 dark:border-slate-700 font-bold scale-102'
                      : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="h-2.5 w-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: slice.color }} />
                    <span className="text-xs text-slate-700 dark:text-slate-300">{slice.name === 'Critical' ? 'Critical / حرج' : slice.name === 'High' ? 'High / عالي' : slice.name === 'Medium' ? 'Medium / متوسط' : 'Low / منخفض'}</span>
                  </div>
                  <span className="text-xs font-bold font-mono text-slate-800 dark:text-slate-100">
                    {slice.count} ({slice.percentage}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-850 flex items-center justify-between">
            <span>Filter view state by click level / تصفية طريقة العرض بالنقر فوق مستوى الخطر</span>
            {selectedRiskFilter && (
              <button
                onClick={() => setSelectedRiskFilter(null)}
                className="text-blue-600 font-semibold uppercase font-mono text-[10px] hover:underline"
              >
                Clear filter / مسح التصفية [x]
              </button>
            )}
          </div>
        </div>

        {/* Bar Chart: Risks by Asset Type */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 lg:col-span-7 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider">
                Threat Profiling by Asset Class / تصنيف التهديدات حسب فئة الأصول
              </h3>
              <span className="text-[10px] font-mono text-slate-400 uppercase">
                Active Count / العدد النشط
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Shows how vulnerabilities map onto specific technological units. / يوضح كيف يتم تصنيف الثغرات الأمنية على خلفية الوحدات التكنولوجية المحددة.
            </p>
          </div>

          <div className="my-6 space-y-4">
            {risksByType.map((item, index) => {
              const widthPct = (item.count / maxBarCount) * 100;
              const isHovered = hoveredBarIndex === index;

              return (
                <div
                  key={item.type}
                  className="space-y-1 group"
                  onMouseEnter={() => setHoveredBarIndex(index)}
                  onMouseLeave={() => setHoveredBarIndex(null)}
                >
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-medium text-slate-700 dark:text-slate-300 flex items-center">
                      <span className="h-1.5 w-1.5 rounded-full mr-2" style={{ backgroundColor: item.color }} />
                      {item.type === 'Software' ? 'Software / البرمجيات' : item.type === 'Hardware' ? 'Hardware / الأجهزة' : item.type === 'Network' ? 'Network / الشبكة' : item.type === 'Data' ? 'Data / البيانات' : 'Physical / المادية'}
                    </span>
                    <span className="font-mono font-bold text-slate-950 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                      {item.count} Risks / مخاطر
                    </span>
                  </div>
                  <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden relative border border-slate-200/40 dark:border-slate-750">
                    <div
                      className="h-full rounded-full transition-all duration-500 ease-out flex items-center justify-end px-2"
                      style={{
                        width: `${Math.max(widthPct, 6)}%`,
                        backgroundColor: item.color,
                        boxShadow: isHovered ? `0 0 12px ${item.color}55` : 'none'
                      }}
                    >
                      {item.count > 0 && widthPct > 15 && (
                        <span className="text-[9px] font-bold text-white font-mono leading-none">
                          {Math.round(widthPct)}%
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-850 flex items-center justify-between">
            <span>Primary vectors are Cloud & Software Gateways / المسارات الأساسية تشمل بوابات الحوسبة والبرمجيات</span>
            <span className="font-medium font-mono text-[10px] text-slate-500">
              Max weight = {maxBarCount}
            </span>
          </div>
        </div>
      </div>

      {/* Alert Section: Critical Risks */}
      <div id="critical-alerts-section" className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider flex items-center">
              <span className="h-2.5 w-2.5 bg-rose-500 rounded-full mr-2.5 animate-pulse" />
              Critical Threat Mitigation Ledger / سجل معالجة التهديدات الحرجة
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Active risks calling for immediate system patching or operational workarounds. / المخاطر النشطة التي تتطلب معالجة برمجية فورية أو حلولاً تشغيلية عاجلة.
            </p>
          </div>
          <span className="text-xs bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 font-mono font-bold px-3 py-1 rounded-xl">
            {criticalAlerts.length} HOTSPOTS ACTIVE / نقاط حاسمة نشطة
          </span>
        </div>

        {selectedRiskFilter && (
          <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl flex items-center justify-between text-xs text-blue-800 dark:text-blue-300 border border-blue-100 dark:border-blue-900/60 font-medium font-mono">
            <span>Showing only threat level / عرض مستوى الخطر فقط: <strong>{selectedRiskFilter}</strong></span>
            <button
              onClick={() => setSelectedRiskFilter(null)}
              className="text-xs text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
            >
              Clear filter / مسح التصفية
            </button>
          </div>
        )}

        <div className="space-y-3">
          {criticalAlerts.filter(r => !selectedRiskFilter || r.level === selectedRiskFilter).length === 0 ? (
            <div className="p-8 text-center bg-slate-50 dark:bg-slate-850 rounded-xl text-slate-400 text-xs font-mono">
              ✔️ No critical risk factors match current ledger search context. / لا توجد عوامل خطر تطابق سياق البحث الحالي في السجل.
            </div>
          ) : (
            criticalAlerts
              .filter(r => !selectedRiskFilter || r.level === selectedRiskFilter)
              .map((risk) => {
                const associatedAsset = assets.find((a) => a.id === risk.assetId);
                const isCritical = risk.level === 'Critical';

                return (
                  <div
                    key={risk.id}
                    className="p-4 rounded-xl border transition-all duration-200 hover:-translate-y-0.5 hover:shadow-sm bg-slate-50 dark:bg-slate-950/30 border-slate-100 dark:border-slate-855/60 flex flex-col md:flex-row md:items-start justify-between gap-4"
                  >
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-full ${
                          isCritical
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200'
                            : 'bg-orange-100 text-orange-850 dark:bg-orange-900/30 dark:text-orange-300'
                        }`}>
                          {risk.level === 'Critical' ? 'Critical / حرج' : 'High / عالي'} Severity / الشدة
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">
                          ID / المعرف: {risk.id}
                        </span>
                        <span className="text-xs text-slate-500 font-medium font-mono">
                          Target / الهدف: {associatedAsset?.name || 'Network Node'}
                        </span>
                      </div>
                      
                      <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100">
                        {risk.name}
                      </h4>
                      <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                        <strong className="text-slate-700 dark:text-slate-300">Vector Status / تفاصيل المسار:</strong> {risk.threatSource}
                      </p>
                      <div className="p-3 bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-800/80 rounded-lg text-xs">
                        <span className="font-semibold text-indigo-700 dark:text-indigo-400">Prescribed Remediation / العلاج المقترح:</span>{' '}
                        <span className="text-slate-600 dark:text-slate-300">{risk.mitigation}</span>
                      </div>
                    </div>

                    <div className="flex flex-row md:flex-col justify-end gap-2.5 items-end self-center md:self-start">
                      <div className="text-right hidden md:block">
                        <p className="text-[10px] font-mono text-slate-400">Assigned Impact / التأثير المعين</p>
                        <p className="text-xs font-bold text-rose-600 font-mono">{risk.impact}</p>
                      </div>
                      <div className="flex items-center space-x-2 font-mono">
                        {onUpdateRiskStatus && risk.status !== 'Mitigated' ? (
                          <button
                            onClick={() => onUpdateRiskStatus(risk.id, 'Mitigated')}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs leading-none cursor-pointer flex items-center shadow-sm shadow-emerald-500/10 active:scale-98 transition-all"
                          >
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Mark Mitigated / تحديد كمعالج
                          </button>
                        ) : (
                          <span className="px-3 py-1.5 bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-450 rounded-lg text-xs font-mono font-bold flex items-center">
                            <ShieldCheck className="h-3.5 w-3.5 mr-1 text-emerald-500" />
                            Mitigated State / تم المعالجة
                          </span>
                        )}
                        <button
                          onClick={() => onNavigate('risk')}
                          className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg border border-slate-200 dark:border-slate-800 cursor-pointer"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
          )}
        </div>
      </div>
    </div>
  );
}
