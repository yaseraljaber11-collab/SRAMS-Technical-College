/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  ShieldAlert,
  FolderLock,
  Skull,
  BarChart3,
  Settings,
  HelpCircle,
  Users
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  assetsCount: number;
  risksCount: number;
  incidentsCount: number;
  isSidebarOpen?: boolean;
  onCloseSidebar?: () => void;
}

export default function Sidebar({
  currentView,
  onNavigate,
  assetsCount,
  risksCount,
  incidentsCount,
  isSidebarOpen = false,
  onCloseSidebar
}: SidebarProps) {
  const menuItems = [
    {
      id: 'dashboard',
      label: 'Dashboard / لوحة التحكم',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'asset',
      label: 'Asset Management / إدارة الأصول',
      icon: FolderLock,
      badge: assetsCount
    },
    {
      id: 'risk',
      label: 'Risk Management / إدارة المخاطر',
      icon: ShieldAlert,
      badge: risksCount
    },
    {
      id: 'incident',
      label: 'Incident Reporting / الإبلاغ عن الحوادث',
      icon: Skull,
      badge: incidentsCount
    },
    {
      id: 'analytics',
      label: 'Reports & Analytics / التقارير والتحليلات',
      icon: BarChart3,
      badge: null
    },
    {
      id: 'settings',
      label: 'Settings / الإعدادات',
      icon: Settings,
      badge: null
    }
  ];

  return (
    <aside className={`fixed top-16 left-0 bottom-0 w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col justify-between pt-4 pb-6 z-30 transition-transform duration-300 ease-in-out ${
      isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
    }`}>
      {/* Navigation Links */}
      <div className="flex-1 px-4 space-y-1">
        <div className="px-3 mb-4">
          <p className="text-[10px] font-bold tracking-widest text-slate-500 uppercase">
            Security Control Panel / لوحة التحكم الأمني
          </p>
        </div>
        <nav className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group cursor-pointer ${
                  isActive
                    ? 'bg-blue-600/15 text-blue-400 border-l-4 border-blue-500 font-semibold pl-4'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60 border-l-4 border-transparent'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon
                    className={`h-4.5 w-4.5 transition-colors duration-200 ${
                      isActive ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge !== null && (
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-blue-600/30 text-blue-300'
                        : 'bg-slate-800 text-slate-400 group-hover:bg-slate-700'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* College Footer & Version Info */}
      <div className="px-6 border-t border-slate-800 pt-4">
        <div className="p-3 bg-slate-950/40 border border-slate-800 rounded-lg text-center">
          <p className="text-xs font-semibold text-slate-300">
            SRAMS Node Client / عميل نظام إدارة وتحليل المخاطر الأمنية
          </p>
          <p className="text-[10px] font-mono text-slate-500 mt-1">
            Build v4.12.26
          </p>
          <div className="mt-2 flex items-center justify-center space-x-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">
              Live Connection / اتصال مباشر
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
