/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Plus,
  Search,
  CheckCircle,
  HelpCircle,
  Trash2,
  X,
  PlusCircle,
  TrendingDown,
  Activity,
  Edit,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  FileSpreadsheet
} from 'lucide-react';
import { Asset, Risk, calculateRiskLevel } from '../types';

interface RiskManagerProps {
  risks: Risk[];
  assets: Asset[];
  onAddRisk: (risk: Risk) => void;
  onEditRisk: (risk: Risk) => void;
  onDeleteRisk: (id: string) => void;
  onUpdateRiskStatus: (riskId: string, status: Risk['status']) => void;
}

export default function RiskManager({
  risks,
  assets,
  onAddRisk,
  onEditRisk,
  onDeleteRisk,
  onUpdateRiskStatus
}: RiskManagerProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRisk, setEditingRisk] = useState<Risk | null>(null);

  // Search/Filters states
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Form states
  const [formData, setFormData] = useState<Omit<Risk, 'id' | 'level'>>({
    name: '',
    assetId: assets[0]?.id || '',
    likelihood: 'Medium',
    impact: 'Medium',
    threatSource: '',
    mitigation: '',
    status: 'Identified'
  });

  const handleOpenAddForm = () => {
    setEditingRisk(null);
    setFormData({
      name: '',
      assetId: assets[0]?.id || '',
      likelihood: 'Medium',
      impact: 'Medium',
      threatSource: '',
      mitigation: '',
      status: 'Identified'
    });
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (risk: Risk) => {
    setEditingRisk(risk);
    setFormData({
      name: risk.name,
      assetId: risk.assetId,
      likelihood: risk.likelihood,
      impact: risk.impact,
      threatSource: risk.threatSource,
      mitigation: risk.mitigation,
      status: risk.status
    });
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const computedLevel = calculateRiskLevel(formData.likelihood, formData.impact);

    if (editingRisk) {
      onEditRisk({
        ...editingRisk,
        ...formData,
        level: computedLevel
      });
    } else {
      onAddRisk({
        id: `rsk-${Date.now().toString().slice(-3)}`,
        ...formData,
        level: computedLevel
      });
    }

    setIsFormOpen(false);
    setEditingRisk(null);
  };

  // Filter computation
  const filteredRisks = risks.filter((risk) => {
    const matchesSearch =
      risk.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.threatSource.toLowerCase().includes(searchQuery.toLowerCase()) ||
      risk.mitigation.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesLevel = levelFilter === 'All' || risk.level === levelFilter;
    const matchesStatus = statusFilter === 'All' || risk.status === statusFilter;

    return matchesSearch && matchesLevel && matchesStatus;
  });

  // Risk visual color styles mapping
  const getRiskBadgeStyles = (level: Risk['level']) => {
    switch (level) {
      case 'Low':
        return 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-300 border-emerald-200 text-center font-bold';
      case 'Medium':
        return 'bg-yellow-50 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-350 border-yellow-200 text-center font-bold';
      case 'High':
        return 'bg-orange-50 text-orange-850 dark:bg-orange-950/20 dark:text-orange-350 border-orange-200 text-center font-bold';
      case 'Critical':
        return 'bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300 border-rose-300 text-center font-extrabold animate-pulse';
    }
  };

  const getStatusBadgeStyles = (status: Risk['status']) => {
    switch (status) {
      case 'Mitigated':
        return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300';
      case 'Monitoring':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300';
      case 'Identified':
        return 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300';
    }
  };

  const getAssetName = (id: string) => {
    const asset = assets.find((a) => a.id === id);
    return asset ? asset.name : 'Unknown Campus Asset';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white leading-tight">
            Security Vulnerability & Risk Management Matrix / مصفوفة ثغرات الأمن السيبراني وإدارة المخاطر
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Qualitative and quantitative mapping of vulnerabilities to compute risk coefficients. / المخططات النوعية والكمية للثغرات لحساب مؤشرات مستوى الخطر.
          </p>
        </div>
        <button
          onClick={handleOpenAddForm}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-xl active:translate-y-0.5 transition-all shadow-md shadow-blue-500/10 inline-flex items-center cursor-pointer font-mono"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Propose Threat Model / اقتراح نموذج تهديد جديد
        </button>
      </div>

      {/* Info card on calculation */}
      <div className="p-4 bg-slate-900 text-white rounded-xl shadow-inner border border-slate-800 grid grid-cols-1 md:grid-cols-12 gap-4 items-center font-mono">
        <div className="md:col-span-8 flex items-start space-x-3">
          <ShieldAlert className="h-5 w-5 text-amber-400 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              SRAMS Multiplicative Risk Equation / معادلة الخطر المضاعف
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
              Risk Levels are computed based on Likelihood x Impact (1-4 scale). Cumulative scores (9-16) flag critical warnings automatically. / تُحسب مستويات المخاطر بضرب الاحتمالية × التأثير (بمقياس 1-4). النتيجة (9-16) تطلق تنبيهات حرجة ذاتياً.
            </p>
          </div>
        </div>
        <div className="md:col-span-4 flex justify-end gap-2 text-right">
          <div className="px-3 py-1.5 bg-slate-950/60 border border-slate-800 rounded text-center">
            <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-mono">Likelihood / الاحتمالية</span>
            <span className="text-[11px] font-bold font-mono text-emerald-400">1 - 4 Scale</span>
          </div>
          <div className="px-3 py-1.5 bg-slate-950/60 border border-slate-800 rounded text-center">
            <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-mono">X Impact / التأثير</span>
            <span className="text-[11px] font-bold font-mono text-amber-400">1 - 4 Scale</span>
          </div>
          <div className="px-3 py-1.5 bg-slate-950/60 border border-slate-800 rounded text-center">
            <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-mono">= Risk level / مستوى الخطر</span>
            <span className="text-[11px] font-extrabold font-mono text-rose-500">Color-coded</span>
          </div>
        </div>
      </div>

      {/* Control Filter Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 font-mono">
        {/* Search */}
        <div className="w-full md:w-80 relative">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search threats / ابحث عن التهديدات والمخاطر..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg text-xs border border-slate-200 dark:border-slate-800 focus:outline-none"
          />
        </div>

        {/* Dropdowns */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-end">
          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Threats Severity / كل مستويات الشدة</option>
            <option value="Low">Low Levels / شدة منخفضة</option>
            <option value="Medium">Medium Levels / شدة متوسطة</option>
            <option value="High">High Levels / شدة عالية</option>
            <option value="Critical">Critical Levels / شدة حرجة</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Mitigation States / جميع حالات المعالجة</option>
            <option value="Identified">Identified Only / مٌحدد فقط</option>
            <option value="Monitoring">Monitoring State / تحت المراقبة</option>
            <option value="Mitigated">Mitigated State / تم المعالجة</option>
          </select>

          {(searchQuery !== '' || levelFilter !== 'All' || statusFilter !== 'All') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setLevelFilter('All');
                setStatusFilter('All');
              }}
              className="text-xs text-rose-500 font-semibold hover:underline cursor-pointer"
            >
              Reset Filters / إعادة تعيين
            </button>
          )}
        </div>
      </div>

      {/* Risks Table List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Risk Profile / ID / المخاطر والمعرف</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Associated Asset / الأصل المرتبط</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Likelihood / الاحتمالية</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Impact / التأثير</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400 text-center">Threat Level / مستوى الخطر</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Status / المعالجة</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400 text-right">Actions / إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredRisks.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 px-6">
                    <div className="max-w-md mx-auto space-y-2 text-slate-400">
                      <ShieldCheck className="h-8 w-8 mx-auto text-slate-300" />
                      <p className="text-sm font-semibold">Clean Sheet: Zero threats match / سجل نظيف: لا توجد تهديدات مطابقة</p>
                      <p className="text-xs">No active vulnerabilities align with current table filters. / لا توجد ثغرات نشطة تطابق خيارات التصفية الحالية والتبويب المحدد.</p>
                      <button
                        onClick={handleOpenAddForm}
                        className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-lg mt-3 cursor-pointer"
                      >
                        Map First Danger Vector / تخطيط أول ثغرة وناقل خطر
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredRisks.map((risk) => {
                  return (
                    <tr
                      key={risk.id}
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-all text-xs"
                    >
                      {/* Name columns */}
                      <td className="px-6 py-4 max-w-sm">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-slate-800 dark:text-slate-100">
                              {risk.name}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400 font-bold bg-slate-100 dark:bg-slate-800 px-1 py-0.2 rounded">
                              {risk.id}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-1 italic">
                            Source: {risk.threatSource}
                          </p>
                          <p className="text-[11px] text-slate-500 line-clamp-2 bg-slate-50 dark:bg-slate-950 p-2 rounded border border-slate-150/40">
                            <strong className="text-indigo-650 font-bold">Mitigation:</strong> {risk.mitigation}
                          </p>
                        </div>
                      </td>

                      {/* Associated Asset */}
                      <td className="px-6 py-4">
                        <span className="text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-850 px-2 py-1 rounded font-mono border border-slate-200/50">
                          {getAssetName(risk.assetId)}
                        </span>
                      </td>

                      {/* Likelihood */}
                      <td className="px-6 py-4">
                        <span className="font-semibold text-slate-655 font-mono">
                          {risk.likelihood === 'Low' ? 'Low / منخفض' : risk.likelihood === 'Medium' ? 'Medium / متوسط' : risk.likelihood === 'High' ? 'High / عالي' : 'Critical / حرج'}
                        </span>
                      </td>

                      {/* Impact */}
                      <td className="px-6 py-4">
                        <span className="font-semibold text-slate-655 font-mono">
                          {risk.impact === 'Low' ? 'Low / منخفض' : risk.impact === 'Medium' ? 'Medium / متوسط' : risk.impact === 'High' ? 'High / عالي' : 'Critical / حرج'}
                        </span>
                      </td>

                      {/* Threat Level */}
                      <td className="px-6 py-4 text-center">
                        <span className={`inline-block text-[11px] font-extrabold font-mono px-3 py-1 rounded-lg border w-28 tracking-wide shadow-sm text-center ${getRiskBadgeStyles(risk.level)}`}>
                          {risk.level === 'Low' ? 'Low / منخفض' : risk.level === 'Medium' ? 'Medium / متوسط' : risk.level === 'High' ? 'High / عالي' : 'Critical / حرج'}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-6 py-4">
                        <span className={`inline-block text-[10px] font-bold font-mono px-2 py-0.5 rounded-full ${getStatusBadgeStyles(risk.status)}`}>
                          {risk.status === 'Identified' ? 'Identified / تم تحديده' : risk.status === 'Monitoring' ? 'Monitoring / قيد المراقبة' : 'Mitigated / تم معالجته'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right font-mono">
                        <div className="flex items-center justify-end space-x-2">
                          {risk.status !== 'Mitigated' && (
                            <button
                              onClick={() => onUpdateRiskStatus(risk.id, 'Mitigated')}
                              className="p-1 px-2 text-emerald-600 hover:text-emerald-800 rounded bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/40 cursor-pointer text-[10px]"
                              title="Resolve / Mitigate / معالجة الخطر"
                            >
                              Mitigate / معالجة
                            </button>
                          )}
                          <button
                            onClick={() => handleOpenEditForm(risk)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 rounded bg-blue-50 cursor-pointer"
                            title="Edit Risk Matrix / تعديل مصفوفة الخطر"
                          >
                            <Edit className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Remove custom risk ledger entry ${risk.id} permanently? / هل تفضل حذف قيد الخطر المسجل ${risk.id} بشكل نهائي من السجلات الدائمة؟`)) {
                                onDeleteRisk(risk.id);
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:text-rose-850 rounded bg-rose-50 cursor-pointer"
                            title="Delete Threat Vector"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL DIALOG FORM TO PROPOSE/EDIT RISK VECTORS */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-850 overflow-hidden transform animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center font-mono">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider">
                  {editingRisk ? 'Modify Threat Coefficient / تعديل مصفوفة ناقل الخطر' : 'Propose Threat Vulnerability Profile / اقتراح ثغرة أو ناقل خطر جديد'}
                </h3>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Qualitative Likelihood x Impact Assessment / التقييم النوعي للاحتمالية ومستوى الأثر في الكلية
                </p>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-white rounded-lg p-1 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Name/Threat Description */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Threat Vulnerability Manifest Statement / بيان مmanifest الثغرة والتهديد الأمني الموجه للأصل *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Insecure access point allows ARP spoof attacks on Campus Admin Wifi"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                />
              </div>

              {/* Asset Mapping Selector */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Associated College Asset Target / الأصل الجامعي التقني المستهدف بالخطر *
                </label>
                {assets.length === 0 ? (
                  <p className="text-xs text-rose-500 font-medium leading-none">
                    Please register an asset in Asset Management before establishing risks. / يرجى تسجيل أصل مدرج أولاً في إدارة الأصول قبل رسم المخاطر.
                  </p>
                ) : (
                  <select
                    value={formData.assetId}
                    onChange={(e) => setFormData({ ...formData, assetId: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-750 dark:text-slate-350 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                  >
                    {assets.map((asset) => (
                      <option key={asset.id} value={asset.id}>
                        {asset.name} ({asset.id})
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {/* Grids Likelihood & Impact & Calculated preview */}
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200/50 rounded-xl space-y-3 font-mono">
                <span className="text-[10px] font-bold uppercase tracking-widest block text-slate-450">
                  Threat Metrics Form / تفاصيل مستويات ناقل التهديد
                </span>

                <div className="grid grid-cols-2 gap-4">
                  {/* Likelihood */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-450 block">
                      Likelihood Threshold / احتمالية حدوث الثغرة
                    </label>
                    <select
                      value={formData.likelihood}
                      onChange={(e) => setFormData({ ...formData, likelihood: e.target.value as Risk['likelihood'] })}
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                    >
                      <option value="Low">Low (1- rare remote risk / منخفض - نادر وقليل الحدوث)</option>
                      <option value="Medium">Medium (2- possible/unpatched / متوسط - ممكن أو غير محصن جيداً)</option>
                      <option value="High">High (3- highly vulnerable sector / عالي - ثغرة مرصودة بالكامل)</option>
                      <option value="Critical">Critical (4- actively leveraged threat / حرج - استغلال مادي مباشر)</option>
                    </select>
                  </div>

                  {/* Impact */}
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-450 block">
                      Impact Core Threat / درجة الأثر والضرر الفني بالكلية
                    </label>
                    <select
                      value={formData.impact}
                      onChange={(e) => setFormData({ ...formData, impact: e.target.value as Risk['impact'] })}
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                    >
                      <option value="Low">Low (1- marginal compliance drift / منخفض - درجة انحراف بسيطة بالمعايير)</option>
                      <option value="Medium">Medium (2- sectional disruption / متوسط - تعطيل لبعض شعب الفصول أو الأقسام)</option>
                      <option value="High">High (3- student outage / data block / عالي - حظر بيانات الطلاب أو خدماتهم)</option>
                      <option value="Critical">Critical (4- campus-wide failure/recovery / حرج - توقف كامل لنظام الكلية للتعافي بالكامل)</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-500 font-bold">
                    Calculated Threat Level outcome / النتيجة الحسابية المقررة لمستوى الخطر:
                  </span>
                  <span className={`px-4 py-1.5 rounded-lg border text-xs font-bold tracking-widest ${getRiskBadgeStyles(calculateRiskLevel(formData.likelihood, formData.impact))}`}>
                    {calculateRiskLevel(formData.likelihood, formData.impact) === 'Low' ? 'Low / منخفض' : calculateRiskLevel(formData.likelihood, formData.impact) === 'Medium' ? 'Medium / متوسط' : calculateRiskLevel(formData.likelihood, formData.impact) === 'High' ? 'High / عالي' : 'Critical / حرج'}
                  </span>
                </div>
              </div>

              {/* Threat Source Input */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Threat Source description / مصدر وبيئة التهديد المحتمل
                </label>
                <input
                  type="text"
                  value={formData.threatSource}
                  onChange={(e) => setFormData({ ...formData, threatSource: e.target.value })}
                  placeholder="e.g. Internals, Scripted SQL Injections, Phishing target routes"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-sans"
                />
              </div>

              {/* Mitigation input */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Prescribed Technical Mitigation / الإجراءات والتدابير المعالجة المقررة للتحصين
                </label>
                <textarea
                  rows={2}
                  value={formData.mitigation}
                  onChange={(e) => setFormData({ ...formData, mitigation: e.target.value })}
                  placeholder="e.g. Enforce single-sign on, activate honeypots, upgrade patch, schedule audit..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-sans"
                />
              </div>

              {/* Mitigation status drop */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Mitigation Operational Status / الحالة الإجرائية والتشغيلية للمعالجة
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as Risk['status'] })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-750 dark:text-slate-350 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                >
                  <option value="Identified">Identified Only (No operational action yet) / تم تحديده فقط (لم يتخذ إجراء تشغيلي بعد)</option>
                  <option value="Monitoring">Monitoring State (Active threat with safe blockages) / قيد المراقبة (تهديد نشط مع تحصينات بيئية مرصودة)</option>
                  <option value="Mitigated">Mitigated State (Full code security resolution applied) / تم المعالجة الكاملة (تم تطبيق سد الثغرة بالكامل)</option>
                </select>
              </div>

              {/* Form actions footer */}
              <div className="pt-4 border-t border-slate-150 flex justify-end space-x-3 bg-slate-50 -mx-6 -mb-6 p-4 font-mono">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-250 hover:bg-slate-100 text-slate-750 font-semibold text-xs rounded-lg cursor-pointer"
                >
                  Discard Proposal / إلغاء
                </button>
                <button
                  type="submit"
                  disabled={assets.length === 0}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm font-sans shadow-blue-500/10 cursor-pointer disabled:opacity-50"
                >
                  {editingRisk ? 'Save Coefficient Changes / حفظ التغييرات' : 'Publish Threat Equation / نشر مصفوفة الخطر'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
