/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Plus,
  Search,
  SlidersHorizontal,
  Trash2,
  Edit,
  Eye,
  Info,
  Server,
  Network,
  Database,
  Monitor,
  Building,
  X,
  MapPin,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { Asset } from '../types';

interface AssetManagerProps {
  assets: Asset[];
  onAddAsset: (asset: Asset) => void;
  onEditAsset: (asset: Asset) => void;
  onDeleteAsset: (id: string) => void;
  onNavigateToRisk?: () => void;
}

export default function AssetManager({
  assets,
  onAddAsset,
  onEditAsset,
  onDeleteAsset,
  onNavigateToRisk
}: AssetManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);
  const [viewingAsset, setViewingAsset] = useState<Asset | null>(null);

  // Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [valueFilter, setValueFilter] = useState<string>('All');

  // Form State
  const [formData, setFormData] = useState<Omit<Asset, 'id'>>({
    name: '',
    type: 'Software',
    value: 'Medium',
    location: '',
    owner: '',
    ipAddress: '',
    description: ''
  });

  // Handle open modal for ADD
  const handleOpenAddModal = () => {
    setEditingAsset(null);
    setFormData({
      name: '',
      type: 'Software',
      value: 'Medium',
      location: '',
      owner: '',
      ipAddress: '',
      description: ''
    });
    setIsModalOpen(true);
  };

  // Handle open modal for EDIT
  const handleOpenEditModal = (asset: Asset) => {
    setEditingAsset(asset);
    setFormData({
      name: asset.name,
      type: asset.type,
      value: asset.value,
      location: asset.location,
      owner: asset.owner,
      ipAddress: asset.ipAddress || '',
      description: asset.description
    });
    setIsModalOpen(true);
  };

  // Handle form submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.location.trim()) {
      return;
    }

    if (editingAsset) {
      onEditAsset({
        ...formData,
        id: editingAsset.id
      });
    } else {
      onAddAsset({
        ...formData,
        id: `ast-${Date.now().toString().slice(-3)}`
      });
    }

    setIsModalOpen(false);
    setEditingAsset(null);
  };

  // Filter calculations
  const filteredAssets = assets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (asset.ipAddress && asset.ipAddress.includes(searchQuery)) ||
      asset.owner.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesType = typeFilter === 'All' || asset.type === typeFilter;
    const matchesValue = valueFilter === 'All' || asset.value === valueFilter;

    return matchesSearch && matchesType && matchesValue;
  });

  // Icon selector based on Asset Type
  const getAssetIcon = (type: Asset['type']) => {
    switch (type) {
      case 'Software':
        return Database;
      case 'Network':
        return Network;
      case 'Data':
        return Server;
      case 'Hardware':
        return Monitor;
      case 'Physical':
        return Building;
      default:
        return Server;
    }
  };

  // Color mapper for asset value importance indicators
  const getValueBadgeStyle = (value: Asset['value']) => {
    switch (value) {
      case 'Low':
        return 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-300 border-emerald-200/50';
      case 'Medium':
        return 'bg-amber-50 text-amber-800 dark:bg-amber-900/20 dark:text-amber-300 border-amber-200/50';
      case 'High':
        return 'bg-orange-50 text-orange-850 dark:bg-orange-950/30 dark:text-orange-350 border-orange-200/50';
      case 'Critical':
        return 'bg-rose-50 text-rose-700 dark:bg-rose-900/35 dark:text-rose-300 border-rose-250';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white leading-tight">
            College Information Inventory / جرد أصول معلومات الكلية
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Registered technology systems, servers, gateways, and networks demanding risk profiles. / الأنظمة التقنية المسجلة والخوادم والبوابات والشبكات التي تتطلب ملفات تعريف المخاطر.
          </p>
        </div>
        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 font-semibold text-white rounded-xl text-xs active:translate-y-0.5 transition-all shadow-md shadow-blue-500/10 inline-flex items-center cursor-pointer font-mono"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Register New Asset / تسجيل أصل جديد
        </button>
      </div>

      {/* Control Filters Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 font-mono">
        {/* Search Input bar */}
        <div className="w-full md:w-96 relative">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search assets / ابحث عن الأصول..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg text-xs border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>

        {/* Dropdowns filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span>Filters / تصفية:</span>
          </div>

          {/* Type dropdown Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Types / كل الأنواع</option>
            <option value="Software">Software / البرمجيات</option>
            <option value="Network">Network / الشبكة</option>
            <option value="Data">Data / البيانات</option>
            <option value="Hardware">Hardware / الأجهزة</option>
            <option value="Physical">Physical / المادية</option>
          </select>

          {/* Value urgency Filter */}
          <select
            value={valueFilter}
            onChange={(e) => setValueFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Importance / كل الأهمية</option>
            <option value="Low">Low Importance / أهمية منخفضة</option>
            <option value="Medium">Medium Importance / أهمية متوسطة</option>
            <option value="High">High Importance / أهمية عالية</option>
            <option value="Critical">Critical Business Value / قيمة عمل حرجة</option>
          </select>

          {/* Clear filters Button */}
          {(typeFilter !== 'All' || valueFilter !== 'All' || searchQuery !== '') && (
            <button
              onClick={() => {
                setTypeFilter('All');
                setValueFilter('All');
                setSearchQuery('');
              }}
              className="text-xs text-rose-500 hover:underline cursor-pointer font-semibold ml-2"
            >
              Reset Filters / إعادة تعيين
            </button>
          )}
        </div>
      </div>

      {/* Main Table Content */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 font-mono">
                <th className="px-6 py-4 text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400">Asset Name & Class / اسم فئة الأصل</th>
                <th className="px-6 py-4 text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400">Asset Type / نوع الأصل</th>
                <th className="px-6 py-4 text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400">Security Importance / الأهمية الأمنية</th>
                <th className="px-6 py-4 text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400">Host, Physical Location / المكان المادي</th>
                <th className="px-6 py-4 text-xs font-bold tracking-wider uppercase text-slate-500 dark:text-slate-400 text-right">Actions / إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
              {filteredAssets.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 px-6">
                    <div className="max-w-md mx-auto space-y-2 text-slate-400">
                      <Info className="h-8 w-8 mx-auto text-slate-300" />
                      <p className="text-sm font-semibold">No college assets match parameters. / لا توجد أصول مطابقة للمعايير المحددة.</p>
                      <p className="text-xs">Adjust filters or register high priority servers immediately. / يرجى تعديل خيارات التصفية أو تسجيل الخوادم ذات الأولوية العالية فوراً.</p>
                      <button
                        onClick={handleOpenAddModal}
                        className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-lg hover:bg-slate-200 transition-all mt-3 cursor-pointer"
                      >
                        Register First Asset / تسجيل الأصل الأول
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredAssets.map((asset) => {
                  const TypeIcon = getAssetIcon(asset.type);

                  return (
                    <tr
                      key={asset.id}
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-all"
                    >
                      {/* Name columns */}
                      <td className="px-6 py-4">
                        <div className="flex items-start space-x-3.5">
                          <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 flex-shrink-0">
                            <TypeIcon className="h-4.5 w-4.5" />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <span
                                className="font-bold text-sm text-slate-800 dark:text-slate-100 hover:text-blue-600 cursor-pointer"
                                onClick={() => setViewingAsset(asset)}
                              >
                                {asset.name}
                              </span>
                              <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-400 font-bold">
                                {asset.id}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1 max-w-sm font-sans">
                              {asset.description}
                            </p>
                            {asset.ipAddress && (
                              <span className="inline-block mt-1 bg-blue-50/50 text-blue-700 font-mono text-[10px] px-1.5 py-0.2 rounded border border-blue-100 dark:bg-blue-900/10 dark:text-blue-300 dark:border-blue-900/30">
                                IP: {asset.ipAddress}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Type column */}
                      <td className="px-6 py-4">
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 border border-slate-200/40 dark:border-slate-750 px-2.5 py-1 rounded-lg">
                          {asset.type === 'Software' ? 'Software / برمجيات' : asset.type === 'Hardware' ? 'Hardware / أجهزة والمعدات' : asset.type === 'Data' ? 'Data / بيانات ومعلومات' : asset.type === 'Network' ? 'Network / شبكات واتصالات' : 'Physical / مادية وبنية تحتية'}
                        </span>
                      </td>

                      {/* Urgency Value column */}
                      <td className="px-6 py-4 font-sans">
                        <span className={`text-xs font-bold font-mono px-2.5 py-1 rounded-lg border ${getValueBadgeStyle(asset.value)}`}>
                          {asset.value === 'Low' ? 'Low / منخفض' : asset.value === 'Medium' ? 'Medium / متوسط' : asset.value === 'High' ? 'High / عالي' : 'Critical / حرج'}
                        </span>
                      </td>

                      {/* Host/Location column */}
                      <td className="px-6 py-4 font-sans">
                        <div className="space-y-0.5">
                          <span className="text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center">
                            <MapPin className="h-3 w-3 mr-1 text-slate-400" />
                            {asset.location}
                          </span>
                          <span className="text-[10px] text-slate-400 block font-mono">
                            Owner / القسم المالك: {asset.owner}
                          </span>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => setViewingAsset(asset)}
                            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-250 cursor-pointer rounded bg-slate-100/40 dark:bg-slate-850"
                            title="View Extended Info / تفاصيل موسعة"
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEditModal(asset)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 cursor-pointer rounded bg-blue-50/55 dark:bg-blue-950/25"
                            title="Edit Asset Entry / تعديل الأصل"
                          >
                            <Edit className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Remove ${asset.name} from the college asset registry permanently? / هل ترغب في إزالة ${asset.name} من سجلات الأصول المعتمدة بشكل دائم؟`)) {
                                onDeleteAsset(asset.id);
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:text-rose-850 cursor-pointer rounded bg-rose-50/50 dark:bg-rose-950/20"
                            title="De-register Asset / إلغاء تسجيل الأصل"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL FORM FOR ADD/EDIT ASSET */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-250 dark:border-slate-850 overflow-hidden transform animate-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center font-mono">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider">
                  {editingAsset ? 'Modify Asset Profile / تعديل ملف الأصل' : 'Register College Asset / تسجيل أصل الكلية'}
                </h3>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  SRAMS Asset Risk Assessment System / نظام إدارة وتحليل مخاطر أصول الكلية التقنية
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white rounded-lg p-1 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Asset Name */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Asset / System Name / اسم الأصل أو النظام التقني *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Student Registration Gateway Portal"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
                />
              </div>

              {/* Grid block */}
              <div className="grid grid-cols-2 gap-4">
                {/* Type Selection */}
                <div className="space-y-1 font-mono">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Asset Class Type / فئة ونوع الأصل
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as Asset['type'] })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-750 dark:text-slate-350 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                  >
                    <option value="Software">Software Instance / منصة - نظام برمجيات</option>
                    <option value="Network">Network Core Hardware / أجهزة خطوط الشبكات</option>
                    <option value="Data">Critical Database/Files / قاعدة بيانات وملفات حساسة</option>
                    <option value="Hardware">Lab/Office Workstation / أجهزة حاسوب مكتبية ومعملية</option>
                    <option value="Physical">Building infrastructure / بنية ترفيق ومباني مادية</option>
                  </select>
                </div>

                {/* Value Selection */}
                <div className="space-y-1 font-mono">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Security Criticality / الأهمية والأثر الأمني
                  </label>
                  <select
                    value={formData.value}
                    onChange={(e) => setFormData({ ...formData, value: e.target.value as Asset['value'] })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-750 dark:text-slate-350 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                  >
                    <option value="Low">Low / منخفضة - خدمات عامة ومحيطية</option>
                    <option value="Medium">Medium / متوسطة - العمليات المعتادة</option>
                    <option value="High">High / عالية - توقف الخدمة بالقسم</option>
                    <option value="Critical">Critical / حرجة جداً - شلل كامل للنظام</option>
                  </select>
                </div>
              </div>

              {/* IP Address and Location */}
              <div className="grid grid-cols-2 gap-4 font-mono">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    IP Address / Domain Alias (Optional) / عنوان الـ IP أو النطاق
                  </label>
                  <input
                    type="text"
                    value={formData.ipAddress}
                    onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                    placeholder="e.g. 10.140.23.4"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Location / Host Environment / الموقع وبيئة الاستضافة *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    placeholder="e.g. AWS Cloud Server Node 12"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-medium"
                  />
                </div>
              </div>

              {/* Owner Division */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Responsible Custodian Division / Owner Name / الاسم والقسم المسؤول المالك للأصل
                </label>
                <input
                  type="text"
                  value={formData.owner}
                  onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
                  placeholder="e.g. Finance Admin Systems Operator"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-medium"
                />
              </div>

              {/* Description */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Description / Function Statement / وصف الأصل وسياقه التشغيلي والتعليمي
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe its purpose, academic roles, dependencies or access levels..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                />
              </div>

              {/* Actions Footer */}
              <div className="pt-4 border-t border-slate-150 flex justify-end space-x-3 bg-slate-50 -mx-6 -mb-6 p-4 font-mono">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-250 hover:bg-slate-100 text-slate-700 font-semibold text-xs rounded-lg active:scale-98 transition-all cursor-pointer"
                >
                  Cancel / إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg shadow-sm shadow-blue-500/10 active:scale-98 transition-all cursor-pointer"
                >
                  {editingAsset ? 'Save Changes / حفظ التغييرات' : 'Register System / تسجيل الأصل'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW EXTENDED INFO POPUP */}
      {viewingAsset && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-850 overflow-hidden transform animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-150 flex justify-between items-center bg-slate-50 dark:bg-slate-950/40 font-mono">
              <div className="flex items-center space-x-2">
                <span className="h-2.5 w-2.5 rounded-full bg-blue-500 animate-pulse" />
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-xs uppercase tracking-wider">
                  Asset Infrastructure Record / سجل البنية التحتية للأصل التقني
                </h3>
              </div>
              <button
                onClick={() => setViewingAsset(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg p-1 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Profile Content */}
            <div className="p-6 space-y-4 text-slate-700 dark:text-slate-350">
              <div className="flex items-start justify-between font-mono">
                <div>
                  <h4 className="text-base font-bold text-slate-900 dark:text-white leading-snug">
                    {viewingAsset.name}
                  </h4>
                  <span className="font-mono text-[10px] text-slate-400 uppercase tracking-widest block mt-0.5">
                    Asset ID / رمز الأصل: {viewingAsset.id}
                  </span>
                </div>
                <span className={`text-xs font-bold font-mono px-3 py-1 rounded-xl border ${getValueBadgeStyle(viewingAsset.value)}`}>
                  {viewingAsset.value === 'Low' ? 'Low / منخفض' : viewingAsset.value === 'Medium' ? 'Medium / متوسط' : viewingAsset.value === 'High' ? 'High / عالي' : 'Critical / حرج'} Security Weight / الثقل الأمني
                </span>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800 rounded-xl space-y-2">
                <p className="text-xs text-slate-500 italic max-w-md">
                  "{viewingAsset.description || 'No extended function outline declared.'}"
                </p>
              </div>

              {/* Metric grids */}
              <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <span className="font-semibold text-slate-400 block uppercase font-mono text-[9px]">Class of Asset / تصنيف وفئة الأصل</span>
                  <span className="text-slate-800 dark:text-slate-200 font-semibold">
                    {viewingAsset.type === 'Software' ? 'Software / برمجيات' : viewingAsset.type === 'Hardware' ? 'Hardware / أجهزة والمعدات' : viewingAsset.type === 'Data' ? 'Data / بيانات ومعلومات' : viewingAsset.type === 'Network' ? 'Network / شبكات واتصالات' : 'Physical / مادية وبنية تحتية'}
                  </span>
                </div>
                <div>
                  <span className="font-semibold text-slate-400 block uppercase font-mono text-[9px]">Administrative Custodian / الشُعبة المسؤولية</span>
                  <span className="text-slate-800 dark:text-slate-200 font-semibold">{viewingAsset.owner}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-400 block uppercase font-mono text-[9px]">Local Host IP Address / عنوان الـ IP للمضيف</span>
                  <span className="text-slate-800 dark:text-slate-200 font-mono font-medium">{viewingAsset.ipAddress || 'Intranet Route N/A'}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-400 block uppercase font-mono text-[9px]">Environment deployment / بيئة الاستضافة والنشر</span>
                  <span className="text-slate-800 dark:text-slate-200 font-semibold flex items-center">
                    <MapPin className="h-3.5 w-3.5 text-blue-500 mr-1" />
                    {viewingAsset.location}
                  </span>
                </div>
              </div>

              {/* Warning Notice links */}
              <div className="pt-4 border-t border-slate-150 flex flex-col sm:flex-row justify-between items-center gap-3 font-mono">
                <button
                  onClick={() => {
                    setViewingAsset(null);
                    if (onNavigateToRisk) onNavigateToRisk();
                  }}
                  className="text-xs text-amber-600 hover:text-amber-800 font-semibold flex items-center cursor-pointer hover:underline"
                >
                  <ShieldAlert className="h-3.5 w-3.5 mr-1" />
                  Audit Active Risks against {viewingAsset.id} / تدقيق المخاطر النشطة
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleOpenEditModal(viewingAsset)}
                    className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-xs rounded-lg cursor-pointer"
                  >
                    Edit Profile / تعديل
                  </button>
                  <button
                    onClick={() => setViewingAsset(null)}
                    className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg cursor-pointer"
                  >
                    Dismiss Record / إغلاق
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
