/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  ShieldCheck,
  Plus,
  Trash2,
  Lock,
  Globe,
  Settings,
  Mail,
  UserCheck,
  Building,
  CheckCircle,
  ToggleLeft,
  ToggleRight,
  RefreshCw,
  Search
} from 'lucide-react';
import { UserRole } from '../types';

interface SettingsProps {
  roles: UserRole[];
  onAddUser: (user: UserRole) => void;
  onEditUser: (user: UserRole) => void;
  onDeleteUser: (id: string) => void;
}

export default function SettingsPage({
  roles,
  onAddUser,
  onEditUser,
  onDeleteUser
}: SettingsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);

  // Form states
  const [formData, setFormData] = useState<Omit<UserRole, 'id' | 'lastActive'>>({
    name: '',
    email: '',
    role: 'IT Staff',
    department: 'Cybersecurity & IT Infrastructure'
  });

  const [mfaEnabled, setMfaEnabled] = useState(true);
  const [ssoDomain, setSsoDomain] = useState('ahad-rafidah-college.edu');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('All');

  // New staff trigger
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim()) return;

    onAddUser({
      id: `usr-${Date.now().toString().slice(-3)}`,
      lastActive: 'Active Just Now',
      ...formData
    });

    setFormData({
      name: '',
      email: '',
      role: 'IT Staff',
      department: 'Cybersecurity & IT Infrastructure'
    });
    setIsAddOpen(false);
  };

  const filteredRoles = roles.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.department.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = selectedRoleFilter === 'All' || user.role === selectedRoleFilter;

    return matchesSearch && matchesRole;
  });

  const getRoleBadgeStyle = (role: UserRole['role']) => {
    switch (role) {
      case 'Admin':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 font-bold';
      case 'IT Staff':
        return 'bg-indigo-100 text-indigo-805 dark:bg-indigo-900/30 dark:text-indigo-305';
      case 'Security Auditor':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Page Title */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white leading-tight">
          System Administration & Role Settings / إدارة النظام وإعدادات الصلاحيات
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Configure security authorization, campus directory syncing, domain controls, and access tokens. / تهيئة التفويض الأمني، ومزامنة دليل الحرم الجامعي، وضوابط النطاق، ورموز الوصول.
        </p>
      </div>

      {/* Grid Settings Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Side: Users list (IT Administrators Directory) */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 lg:col-span-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider flex items-center">
                <Users className="h-4 w-4 mr-2 text-slate-500" />
                Authorized Security Division Staff / موظفو شُعبة الأمن السيبراني المصرح لهم
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Personnel holding active authorization tokens for SRAMS database access. / الموظفون الذين يحملون رموز تفويض نشطة للوصول لقاعدة بيانات النظام.
              </p>
            </div>
            <button
              onClick={() => setIsAddOpen(!isAddOpen)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg active:scale-98 transition-all flex items-center cursor-pointer font-mono"
            >
              <Plus className="h-3.5 w-3.5 mr-1" />
              Onboard IT Staff / تسجيل موظف تقني
            </button>
          </div>

          {/* Add Staff form inside panel if open */}
          {isAddOpen && (
            <form onSubmit={handleAddSubmit} className="p-4 bg-slate-50 dark:bg-slate-950 border rounded-xl space-y-3 animate-in fade-in slide-in-from-top-3 duration-200">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block font-mono">
                Staff Credentials Form / نموذج بيانات الموظف
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 block">Staff Full Name / الاسم الكامل للموظف *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Eng. Majed bin Hashim"
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900 border text-slate-900 rounded-lg focus:outline-none"
                  />
                </div>
                <div className="space-y-1 font-mono">
                  <label className="text-[11px] font-semibold text-slate-600 block">Email Address / البريد الإلكتروني *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="majed.hashim@college.edu"
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900 border text-slate-900 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 block">SRAMS Security Role / صلاحية النظام الأمنية</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole['role'] })}
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900 border rounded-lg"
                  >
                    <option value="IT Staff">IT Staff (Read/Write Risks & Incidents) / الموظف التقني (قراءة/كتابة المخاطر والحوادث)</option>
                    <option value="Admin">Admin (Full Control, Delete & Config) / المشرف (التحكم الكامل والتهيئة)</option>
                    <option value="Security Auditor">Security Auditor (Read-only, CSV Export) / المدقق الأمني (قراءة فقط والتصدير)</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 block">Department Division / القسم - الشعبة</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900 border text-slate-900 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="px-3 py-1 bg-slate-200 text-slate-700 font-semibold text-xs rounded hover:bg-slate-300 transition-all font-mono cursor-pointer"
                >
                  [x] Close Form / إغلاق النموذج
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-620 hover:bg-blue-710 bg-blue-600 text-white font-semibold text-xs rounded hover:shadow cursor-pointer font-mono"
                >
                  Onboard Division Entry / تسجيل وقبول الموظف بالشعبة
                </button>
              </div>
            </form>
          )}

          {/* Quick Search on roles */}
          <div className="flex gap-2">
            <div className="flex-1 relative font-mono">
              <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search staff by email, names, division... / البحث بالبريد، الاسم، القسم..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg text-xs border border-slate-200 focus:outline-none"
              />
            </div>
            <select
              value={selectedRoleFilter}
              onChange={(e) => setSelectedRoleFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 text-slate-700 text-xs rounded-lg border focus:outline-none font-mono"
            >
              <option value="All">All Roles / كل الصلاحيات</option>
              <option value="Admin">Admin / المشرف</option>
              <option value="IT Staff">IT Staff / الموظف التقني</option>
              <option value="Security Auditor">Auditor / المدقق</option>
            </select>
          </div>

          {/* Users Card rows */}
          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {filteredRoles.map((user) => {
              return (
                <div
                  key={user.id}
                  className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 hover:-translate-y-0.5 hover:shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 dark:bg-slate-950/20"
                >
                  <div className="flex items-center space-x-3.5">
                    <div className="h-9 w-9 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg flex items-center justify-center uppercase font-mono">
                      {user.name.split(' ').map((n) => n[0]).join('').substring(0, 2)}
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-800 dark:text-slate-100 text-xs">{user.name}</span>
                        <span className="text-[9px] font-mono text-slate-400 font-bold">{user.id}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 font-mono flex items-center mt-0.5">
                        <Mail className="h-3 w-3 mr-1 text-slate-400" />
                        {user.email}
                      </p>
                      <p className="text-[10px] text-slate-400 flex items-center mt-0.5">
                        <Building className="h-3 w-3 mr-1 text-slate-400" />
                        Division / الشعبة: {user.department}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-3.5">
                    <div className="text-right">
                      <span className={`inline-block text-[10px] font-bold font-mono px-2 py-0.5 rounded-full ${getRoleBadgeStyle(user.role)}`}>
                        {user.role}
                      </span>
                      <span className="block text-[9px] font-mono text-slate-400 mt-1">
                        {user.lastActive}
                      </span>
                    </div>

                    {/* Disable delete on local admin profile YA */}
                    {user.id !== 'usr-401' ? (
                      <button
                        onClick={() => {
                          if (confirm(`Remove custom staff member access credentials for ${user.name}? / هل ترغب في سحب صلاحيات الوصول للموظف ${user.name}؟`)) {
                            onDeleteUser(user.id);
                          }
                        }}
                        className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded cursor-pointer"
                        title="De-register credentials"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    ) : (
                      <span className="h-6 w-1 block" /> // empty fill
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: Simple configuration forms */}
        <div className="space-y-6 lg:col-span-4">
          {/* Compliance policies form layout */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider flex items-center">
                <Lock className="h-4 w-4 mr-2 text-slate-500" />
                MFA & Identity policies / سياسات التحقق الثنائي وإدارة الهوية
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                 college directory synchronization parameters. / معايير مزامنة أدلة الكلية الفنية.
              </p>
            </div>

            <div className="space-y-3.5">
              {/* Force MFA */}
              <div className="flex justify-between items-center py-2.5 border-b border-slate-100 dark:border-slate-800 font-mono">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">Enforce Admin MFA / فرض التحقق الثنائي للمشرفين</span>
                  <span className="text-[10px] text-slate-400 block max-w-[180px]">Forwards custom text credentials requests. / يرسل طلبات التحقق عبر الهاتف مع كل تسجيل دخول لكافة الحسابات.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setMfaEnabled(!mfaEnabled)}
                  className="cursor-pointer text-blue-600 p-1 rounded-lg"
                >
                  {mfaEnabled ? (
                    <ToggleRight className="h-8 w-8 text-blue-600" />
                  ) : (
                    <ToggleLeft className="h-8 w-8 text-slate-400" />
                  )}
                </button>
              </div>

              {/* College domain SSO integration */}
              <div className="space-y-1 py-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 block">Single Sign-On SSO Domain Filter / تصفية نطاق بوابة الدخول الموحد (SSO)</label>
                <div className="relative">
                  <Globe className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                  <input
                    type="text"
                    value={ssoDomain}
                    onChange={(e) => setSsoDomain(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 font-mono text-xs bg-slate-50 border border-slate-200 rounded focus:outline-none dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              {/* Security Advisory policy flag */}
              <div className="p-3 bg-indigo-50/50 dark:bg-slate-950 border border-indigo-100 rounded-lg">
                <p className="text-[11px] text-indigo-700 leading-normal font-medium flex items-start dark:text-indigo-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-indigo-500 mr-2 mt-1 shrink-0" />
                  SRAMS operates behind single sign-on (SSO). Modifications must match college gateway registers. / يعمل النظام خلف بوابة الدخول الموحد (SSO). يجب تطابق التعديلات مع سجلات بوابة الكلية.
                </p>
              </div>

              {/* Save settings action mock notification */}
              <button
                type="button"
                onClick={() => alert('SSO Domain settings updated on Domain Controller router successfully! / تم تحديث إعدادات نطاق الـ SSO بنجاح على موجه وحدة التحكم!')}
                className="w-full py-2 bg-slate-900 hover:bg-slate-950 text-white font-semibold text-xs rounded-lg active:scale-98 transition-all cursor-pointer font-mono text-center block"
              >
                APPLY DIRECTORY CHANGES / تطبيق تغييرات الدليل
              </button>
            </div>
          </div>

          {/* Academic audit policy helper */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 relative space-y-3 shadow-md">
            <span className="text-[9px] font-mono font-bold tracking-widest text-slate-500 uppercase block">
              Auditing Compliance Notice / إشعار تدقيق الامتثال المعياري
            </span>
            <h4 className="text-xs font-bold uppercase text-slate-200 tracking-wider">
              NCAAA Standard Compliance / متطلبات الهيئة الوطنية لتقويم التعليم والاعتماد الفني
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Cybersecurity and vulnerability management dashboards are configured to comply with National Cybersecurity Authority academic infrastructure directories. / تم تهيئة لوحات معلومات الأمن السيبراني وإدارة الثغرات لتتوافق مع أدلة الهيئة الوطنية للأمن السيبراني للأبنية التعليمية الأكاديمية.
            </p>
            <div className="flex items-center space-x-1 text-[11px] text-emerald-400 font-mono">
              <ShieldCheck className="h-4 w-4" />
              <span>SRAMS Certified Compliance OK / النظام معتمد كمتوافق أمنياً</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
