/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, Calendar, Bell, User, HelpCircle, HardDrive, AlertTriangle, Menu, X } from 'lucide-react';
import { Asset, Risk, Incident } from '../types';

interface NavbarProps {
  assets: Asset[];
  risks: Risk[];
  incidents: Incident[];
  onNavigate: (view: string) => void;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
}

export default function Navbar({
  assets,
  risks,
  incidents,
  onNavigate,
  isSidebarOpen = false,
  onToggleSidebar
}: NavbarProps) {
  const [showNotifications, setShowNotifications] = useState(false);

  // Critical items
  const criticalRisks = risks.filter((r) => r.level === 'Critical' || r.level === 'High');
  const openIncidents = incidents.filter((i) => i.status !== 'Closed');

  const notificationCount = criticalRisks.length + openIncidents.length;

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-slate-900 border-b border-slate-800 text-white flex items-center justify-between px-4 md:px-6 z-40">
      {/* Left section combo: Hamburger + Brand logo */}
      <div className="flex items-center space-x-1.5 md:space-x-3">
        {/* Mobile Hamburger menu toggle button */}
        <button
          onClick={onToggleSidebar}
          className="p-1.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg md:hidden cursor-pointer transition-colors mr-0.5"
          title="Toggle Navigation / القائمة الجانبية"
        >
          {isSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>

        {/* Brand Logo & Name */}
        <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <div className="bg-blue-600 p-2 rounded-lg text-white shadow-md shadow-blue-500/10 shrink-0">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <h1 className="text-sm md:text-base font-semibold tracking-tight text-white m-0 leading-tight">
              SRAMS
            </h1>
            <p className="text-[8px] md:text-[10px] text-slate-400 font-mono tracking-wider uppercase leading-none mt-0.5 truncate max-w-[150px] sm:max-w-none">
              Technical College Ahad Rafidah / الكلية التقنية بأحد رفيدة
            </p>
          </div>
        </div>
      </div>

      {/* Global Metadata/Clock & Actions */}
      <div className="flex items-center space-x-6">
        {/* Academic Status Flag */}
        <div className="hidden lg:flex items-center bg-slate-800 border border-slate-700/80 px-3 py-1.5 rounded-md text-xs font-mono text-slate-300">
          <span className="h-2 w-2 rounded-full bg-emerald-500 mr-2 animate-pulse" />
          SYSTEM SECURE &bull; INTRANET COMPLIANT / النظام آمن ومطابق للمعاير
        </div>

        {/* Current Date Display */}
        <div className="hidden md:flex items-center text-slate-300 text-xs">
          <Calendar className="h-4 w-4 mr-2 text-slate-400" />
          <span className="font-mono">May 22, 2026</span>
        </div>

        {/* Notifications Dropdown Container */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg relative cursor-pointer transition-colors"
            title="Notifications Alert Panel"
          >
            <Bell className="h-5 w-5" />
            {notificationCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-rose-600 text-[9px] font-bold text-white flex items-center justify-center animate-bounce">
                {notificationCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-3 w-80 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 py-2 z-50 text-slate-800 dark:text-slate-100 animate-in fade-in slide-in-from-top-3 duration-200">
              <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
                <span className="font-semibold text-xs tracking-wide uppercase text-slate-500 dark:text-slate-400">System Security Alerts / تنبيهات أمن النظام</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-mono font-bold dark:bg-blue-900/40 dark:text-blue-200">
                  {notificationCount} Alerts / تنبيهات
                </span>
              </div>
              <div className="max-h-64 overflow-y-auto">
                {criticalRisks.length === 0 && openIncidents.length === 0 ? (
                  <div className="px-4 py-6 text-center text-xs text-slate-400">
                    No urgent security warnings active. / لا توجد تحذيرات أمنية عاجلة.
                  </div>
                ) : (
                  <>
                    {criticalRisks.map((risk) => (
                      <div
                        key={risk.id}
                        className="p-3 border-b border-slate-50 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer flex items-start space-x-2.5"
                        onClick={() => {
                          onNavigate('risk');
                          setShowNotifications(false);
                        }}
                      >
                        <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 leading-tight">
                            {risk.name}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                            Risk: {risk.level} Level / مستوى الخطر: {risk.level === 'Critical' ? 'حرج' : 'عالي'}
                          </p>
                        </div>
                      </div>
                    ))}
                    {openIncidents.map((inc) => (
                      <div
                        key={inc.id}
                        className="p-3 border-b border-slate-50 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer flex items-start space-x-2.5"
                        onClick={() => {
                          onNavigate('incident');
                          setShowNotifications(false);
                        }}
                      >
                        <HardDrive className="h-4 w-4 text-rose-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 leading-tight">
                            Incident / حادثة: {inc.description.substring(0, 40)}...
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                            Status / الحالة: <span className="text-blue-600 dark:text-blue-400 font-bold">{inc.status === 'Open' ? 'مفتوح' : 'تحت المعالجة'}</span>
                          </p>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
              <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 text-center bg-slate-50 dark:bg-slate-900/50">
                <button
                  onClick={() => {
                    onNavigate('dashboard');
                    setShowNotifications(false);
                  }}
                  className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-800"
                >
                  View Threat Hub / عرض مركز التهديدات
                </button>
              </div>
            </div>
          )}
        </div>

        {/* User Account Capsule */}
        <div className="flex items-center space-x-2 bg-slate-800 border border-slate-700 hover:bg-slate-755 p-1 pr-3 rounded-lg cursor-pointer transition-colors" onClick={() => onNavigate('settings')}>
          <div className="h-7 w-7 rounded-md bg-blue-600 flex items-center justify-center text-xs font-bold text-white uppercase shadow-inner">
            YS
          </div>
          <div className="hidden sm:block text-left">
            <p className="text-xs font-medium text-white leading-none">Y. Al-Shahrani / ي. الشهراني</p>
            <span className="text-[9px] text-slate-400 font-mono">SecAdmin / مسؤول أمني</span>
          </div>
        </div>
      </div>
    </header>
  );
}
