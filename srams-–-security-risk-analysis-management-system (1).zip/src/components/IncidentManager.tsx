/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Skull,
  Plus,
  Search,
  CheckCircle,
  HelpCircle,
  Trash2,
  X,
  Edit,
  Eye,
  AlertOctagon,
  Clock,
  ArrowRight,
  RefreshCw,
  HardDrive
} from 'lucide-react';
import { Incident, Asset } from '../types';

interface IncidentManagerProps {
  incidents: Incident[];
  assets: Asset[];
  onAddIncident: (incident: Incident) => void;
  onEditIncident: (incident: Incident) => void;
  onDeleteIncident: (id: string) => void;
  onUpdateIncidentStatus: (id: string, status: Incident['status'], resolution?: string) => void;
}

export default function IncidentManager({
  incidents,
  assets,
  onAddIncident,
  onEditIncident,
  onDeleteIncident,
  onUpdateIncidentStatus
}: IncidentManagerProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIncident, setEditingIncident] = useState<Incident | null>(null);
  const [resolvingIncident, setResolvingIncident] = useState<Incident | null>(null);

  // Search/Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [severityFilter, setSeverityFilter] = useState<string>('All');

  // Form State
  const [formData, setFormData] = useState<Omit<Incident, 'id' | 'date' | 'time'>>({
    description: '',
    assetId: assets[0]?.id || '',
    severity: 'Medium',
    status: 'Open',
    reportedBy: '',
    resolution: ''
  });

  const [resolutionText, setResolutionText] = useState('');

  const handleOpenAdd = () => {
    setEditingIncident(null);
    setFormData({
      description: '',
      assetId: assets[0]?.id || '',
      severity: 'Medium',
      status: 'Open',
      reportedBy: 'Yaser Al-Shahrani',
      resolution: ''
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (incident: Incident) => {
    setEditingIncident(incident);
    setFormData({
      description: incident.description,
      assetId: incident.assetId,
      severity: incident.severity,
      status: incident.status,
      reportedBy: incident.reportedBy,
      resolution: incident.resolution || ''
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.description.trim()) return;

    // Current date/time formats
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];
    const timeStr = today.toTimeString().substring(0, 5);

    if (editingIncident) {
      onEditIncident({
        ...editingIncident,
        ...formData
      });
    } else {
      onAddIncident({
        id: `inc-${Date.now().toString().slice(-3)}`,
        date: dateStr,
        time: timeStr,
        ...formData
      });
    }

    setIsModalOpen(false);
    setEditingIncident(null);
  };

  const handleResolveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (resolvingIncident) {
      onUpdateIncidentStatus(resolvingIncident.id, 'Closed', resolutionText);
      setResolvingIncident(null);
      setResolutionText('');
    }
  };

  // Filter logic
  const filteredIncidents = incidents.filter((inc) => {
    const matchesSearch =
      inc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inc.reportedBy.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (inc.resolution && inc.resolution.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'All' || inc.status === statusFilter;
    const matchesSeverity = severityFilter === 'All' || inc.severity === severityFilter;

    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const getSeverityBadge = (sev: Incident['severity']) => {
    switch (sev) {
      case 'Low':
        return 'bg-emerald-50 text-emerald-800 border-emerald-100 font-mono';
      case 'Medium':
        return 'bg-amber-50 text-amber-800 border-amber-100 font-mono';
      case 'High':
        return 'bg-orange-50 text-orange-850 border-orange-200 font-mono';
      case 'Critical':
        return 'bg-rose-50 text-rose-700 border-rose-200 font-mono font-bold animate-pulse';
    }
  };

  const getStatusBadge = (status: Incident['status']) => {
    switch (status) {
      case 'Open':
        return 'bg-rose-100 text-rose-800 border-rose-250/20 font-bold';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800 border-blue-250/20 font-bold';
      case 'Closed':
        return 'bg-slate-100 text-slate-700 border-slate-250/20 font-bold';
    }
  };

  const getAssetName = (id: string) => {
    const asset = assets.find((a) => a.id === id);
    return asset ? asset.name : 'Unknown Campus Endpoint';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white leading-tight">
            Active Cyber Incident Log & Dispatcher / سجل ومعالجة حوادث الاختراق السيبراني النشطة
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Logs, tracks, and manages high severity outages, phish attempts, or credential leakages immediately. / نسجل وتتبع وإدارة حالات انقطاع الخدمة شديدة الخطورة ومحاولات التصيد وتسريب البيانات فوراً.
          </p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-xl active:translate-y-0.5 transition-all shadow-md shadow-rose-500/10 inline-flex items-center cursor-pointer font-mono"
        >
          <Plus className="h-4 w-4 mr-1.5" />
          Declare Urgent Incident / الإبلاغ عن حادثة عاجلة
        </button>
      </div>

      {/* Control Filter Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 font-mono">
        {/* Search */}
        <div className="w-full md:w-80 relative">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search incidents / ابحث عن الحوادث..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 rounded-lg text-xs border border-slate-200 dark:border-slate-800 focus:outline-none"
          />
        </div>

        {/* Filters options dropdowns */}
        <div className="flex flex-wrap gap-3 items-center w-full md:w-auto justify-end">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Incidents Statuses / جميع حالات الحوادث</option>
            <option value="Open">Status: Open / الحالة: مفتوح</option>
            <option value="In Progress">Status: In Progress / الحالة: قيد التنفيذ</option>
            <option value="Closed">Status: Closed / الحالة: مغلق</option>
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
          >
            <option value="All">All Impact Severities / جميع مستويات الخطورة</option>
            <option value="Low">Low Severity / شدة منخفضة</option>
            <option value="Medium">Medium Severity / شدة متوسطة</option>
            <option value="High">High Severity / شدة عالية</option>
            <option value="Critical">Critical Severity / شدة حرجة</option>
          </select>

          {(searchQuery !== '' || statusFilter !== 'All' || severityFilter !== 'All') && (
            <button
              onClick={() => {
                setSearchQuery('');
                setStatusFilter('All');
                setSeverityFilter('All');
              }}
              className="text-xs text-rose-500 font-semibold hover:underline cursor-pointer"
            >
              Reset Filters / إعادة تعيين
            </button>
          )}
        </div>
      </div>

      {/* Main Table logs */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Timestamp Date / التاريخ والوقت</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Target Asset / Host / الأصل المستهدف والملحقات</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Description / Log details / التفاصيل والسجل</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Severity / الشدة</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400">Status / الحالة</th>
                <th className="px-6 py-4 text-xs font-bold font-mono tracking-wider uppercase text-slate-500 dark:text-slate-400 text-right">Actions / إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
              {filteredIncidents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 px-6">
                    <div className="max-w-md mx-auto space-y-2 text-slate-400 text-xs font-mono">
                      <CheckCircle className="h-8 w-8 mx-auto text-slate-300" />
                      <p className="text-sm font-semibold">Zero incidents listed / لا يوجد بلاغات عن حوادث مسجلة</p>
                      <p className="text-xs">No active network server threats or incidents align with filters. / لا توجد تهديدات شبكة أو حوادث نشطة تطابق مستويات الفرز الحالية.</p>
                      <button
                        onClick={handleOpenAdd}
                        className="px-3 py-1.5 bg-slate-150 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded font-semibold mt-3 cursor-pointer"
                      >
                        File New Security Notice / تعبئة نموذج بلاغ أمني جديد
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredIncidents.map((inc) => {
                  return (
                    <tr
                      key={inc.id}
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-all text-xs"
                    >
                      {/* Date details */}
                      <td className="px-6 py-4 whitespace-nowrap font-mono text-slate-700 dark:text-slate-300">
                        <div className="flex items-center space-x-2">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          <div>
                            <span className="block font-bold">{inc.date}</span>
                            <span className="block text-[10px] text-slate-400">{inc.time} UTC</span>
                          </div>
                        </div>
                      </td>

                      {/* Targeted system */}
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <span className="font-semibold text-slate-800 dark:text-slate-200">
                            {getAssetName(inc.assetId)}
                          </span>
                          <span className="block text-[9px] font-mono text-slate-400 uppercase">
                            ID: {inc.assetId}
                          </span>
                        </div>
                      </td>

                      {/* Description */}
                      <td className="px-6 py-4 max-w-sm">
                        <div className="space-y-1">
                          <span className="font-bold text-slate-800 dark:text-slate-100 block">
                            {inc.description}
                          </span>
                          <p className="text-[10px] text-slate-400 mt-1">
                            Reported by custodian: <span className="font-bold text-slate-500">{inc.reportedBy}</span>
                          </p>
                          {inc.resolution && (
                            <div className="mt-2 p-2 bg-emerald-50/50 dark:bg-emerald-950/20 rounded border border-emerald-100/50 text-slate-600 dark:text-emerald-300">
                              <strong className="text-emerald-700 dark:text-emerald-450 font-semibold font-mono text-[9px] uppercase tracking-wider block">Resolution summary:</strong>
                              <span className="text-[11px] leading-tight block mt-0.5">{inc.resolution}</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Severity level */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-md border ${getSeverityBadge(inc.severity)}`}>
                          {inc.severity === 'Low' ? 'Low / منخفض' : inc.severity === 'Medium' ? 'Medium / متوسط' : inc.severity === 'High' ? 'High / عالي' : 'Critical / حرج'} Severity / درجة الخطورة
                        </span>
                      </td>

                      {/* Incident Status */}
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-block text-[10px] font-bold px-2.5 py-1 rounded-full border ${getStatusBadge(inc.status)}`}>
                          • {inc.status === 'Open' ? 'Open / مفتوح ونشط' : inc.status === 'In Progress' ? 'In Progress / قيد المعالجة للحل' : 'Closed / مغلق ومحلول'}
                        </span>
                      </td>

                      {/* Action buttons */}
                      <td className="px-6 py-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end space-x-2">
                          {inc.status !== 'Closed' && (
                            <button
                              onClick={() => {
                                setResolvingIncident(inc);
                                setResolutionText(inc.resolution || '');
                              }}
                              className="px-2.5 py-1 text-xs bg-slate-900 hover:bg-slate-800 text-white rounded font-bold cursor-pointer border border-slate-850"
                              title="Set incident resolution logic / تدوين إجراءات سد الثغرة لحل البلاغ"
                            >
                              Resolve / معالجة وإغلاق
                            </button>
                          )}
                          {inc.status === 'Open' && (
                            <button
                              onClick={() => onUpdateIncidentStatus(inc.id, 'In Progress')}
                              className="px-2.5 py-1 text-xs bg-blue-50 text-blue-800 rounded font-bold border border-blue-150 cursor-pointer"
                            >
                              Work on IT / بدء التدخل الفني
                            </button>
                          )}
                          <button
                            onClick={() => handleOpenEdit(inc)}
                            className="p-1 text-slate-405 hover:text-slate-655 cursor-pointer rounded bg-slate-100"
                            title="Edit Record Parameters / تعديل البلاغ المعياري"
                          >
                            <Edit className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Remove custom security outage logs ${inc.id}? / هل تفضل بمحو بلاغ الحادثة الأمنية ${inc.id} نهائياً؟`)) {
                                onDeleteIncident(inc.id);
                              }
                            }}
                            className="p-1 text-rose-600 hover:text-rose-800 cursor-pointer rounded bg-rose-50"
                            title="Delete Record"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* DISPATCH INCIDENT REPORT ADMISSION MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-850 overflow-hidden transform animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center font-mono">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-rose-400">
                  {editingIncident ? 'Modify Cyber Outage Record / تعديل بلاغ الحادثة الأمنية' : 'Declare Campus Incident / الإبلاغ عن حادثة اختراق سيبرانية عاجلة'}
                </h3>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Real-time IT Infrastructure alert dispatching / إخطار تشغيلي مباشر لقسم حوادث الأمن
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white rounded-lg p-1 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Incident Description */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Incident Description/Log details / تفاصيل الحادثة الأمنية المرصودة *
                </label>
                <textarea
                  rows={3}
                  required
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="e.g. Host firewall reports multiple brute force attempts targeting Port 22 SSH on Active Directory controller."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-sans"
                />
              </div>

              {/* Target mapping selector */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-355 block">
                  Associated Vulnerable College Hardware/Software / الأصل التقني بالكلية المستهدف والمتضرر بالحادثة
                </label>
                <select
                  value={formData.assetId}
                  onChange={(e) => setFormData({ ...formData, assetId: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-755 dark:text-slate-355 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                >
                  {assets.map((asset) => (
                    <option key={asset.id} value={asset.id}>
                      {asset.name} ({asset.id})
                    </option>
                  ))}
                </select>
              </div>

              {/* Severity Selection & Reported By */}
              <div className="grid grid-cols-2 gap-4 font-mono">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Observed Outage Severity / مستوى خطورة اختلال الخدمة
                  </label>
                  <select
                    value={formData.severity}
                    onChange={(e) => setFormData({ ...formData, severity: e.target.value as Incident['severity'] })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-755 dark:text-slate-350 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                  >
                    <option value="Low">Low / منخفضة - سلامة وفعالية النظام سليمة</option>
                    <option value="Medium">Medium / متوسطة - تأثر في استطاعة واستجابة النظام</option>
                    <option value="High">High / عالية - توقف ببعض الخدمات الأساسية</option>
                    <option value="Critical">Critical / حرجة - شلل أو تسرّب قاعدة للبيانات بالكامل</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Incident Status Type / حالة احتواء البلاغ
                  </label>
                  <select
                    disabled={!!editingIncident}
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as Incident['status'] })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-755 dark:text-slate-355 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none disabled:opacity-50"
                  >
                    <option value="Open">Status: Live/Open / حالة: نشط ومفتوح</option>
                    <option value="In Progress">Status: In Progress / حالة: قيد المراقبة والمعالجة</option>
                    <option value="Closed">Status: Closed / حالة: مغلق وتم الإصلاح والتحصين</option>
                  </select>
                </div>
              </div>

              {/* Custodian Reporter */}
              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                  Assigned Cybersecurity Officer / Reporter / مهندس الأمن السيبراني المكلّف بالإبلاغ *
                </label>
                <input
                  type="text"
                  required
                  value={formData.reportedBy}
                  onChange={(e) => setFormData({ ...formData, reportedBy: e.target.value })}
                  placeholder="e.g. Yaser Al-Shahrani"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none font-medium"
                />
              </div>

              {/* Optional Existing Resolution */}
              {editingIncident && (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-300 block">
                    Permanent Resolution Summary / ملخص وتقرير الإغلاق والحل النهائي للثغرة
                  </label>
                  <textarea
                    rows={2}
                    value={formData.resolution}
                    onChange={(e) => setFormData({ ...formData, resolution: e.target.value })}
                    placeholder="If resolved, map the patches, blocked IPs, file fixes carried out..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-200 dark:border-slate-800 focus:outline-none"
                  />
                </div>
              )}

              {/* Footer buttons */}
              <div className="pt-4 border-t border-slate-150 flex justify-end space-x-3 bg-slate-50 -mx-6 -mb-6 p-4 font-mono">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-250 hover:bg-slate-100 text-slate-750 font-semibold text-xs rounded-lg cursor-pointer"
                >
                  Discard Incident Notice / إلغاء البلاغ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs rounded-lg shadow-sm font-sans shadow-rose-500/10 cursor-pointer"
                >
                  {editingIncident ? 'Save Parameters / حفظ المعاملات والتعديل' : 'Dispatch Alert Notice / إخطار وإعلان حالة الحادثة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DETAILED RESOLUTION DIALOG */}
      {resolvingIncident && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-md shadow-2xl border border-slate-250 dark:border-slate-800 overflow-hidden transform animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center font-mono">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-emerald-400">
                  Post-Incident Resolution Entry / تسجيل إجراءات احتواء حل الحادثة المغلقة
                </h3>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Confirm solution details for / تأكيد تفاصيل الحل وسد النواقص لـ: {resolvingIncident.id}
                </p>
              </div>
              <button
                onClick={() => setResolvingIncident(null)}
                className="text-slate-400 hover:text-white rounded-lg p-1 hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleResolveSubmit} className="p-6 space-y-4">
              <div className="text-xs text-slate-500 leading-relaxed bg-slate-50 dark:bg-slate-950/40 p-3 rounded-lg border font-mono">
                <strong>Incident reported / البلاغ المرصود:</strong> {resolvingIncident.description}
              </div>

              <div className="space-y-1 font-mono">
                <label className="text-xs font-semibold text-slate-600 dark:text-slate-350 block">
                  Describe Resolution Work / Patches Done / إجراءات سداد الحل والتحصين وقفل الثغرة *
                </label>
                <textarea
                  required
                  rows={3}
                  value={resolutionText}
                  onChange={(e) => setResolutionText(e.target.value)}
                  placeholder="e.g. Cleared domain cache; blocklisted IP range 182.xx.xx; re-configured Cisco firewall rules..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs rounded-lg border border-slate-250 dark:border-slate-800 focus:outline-none"
                />
              </div>

              <div className="pt-4 border-t border-slate-150 flex justify-end space-x-3 font-mono">
                <button
                  type="button"
                  onClick={() => setResolvingIncident(null)}
                  className="px-4 py-2 border border-slate-250 hover:bg-slate-100 text-slate-750 font-semibold text-xs rounded-lg cursor-pointer"
                >
                  Cancel / إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-750 text-white font-semibold text-xs rounded-lg cursor-pointer flex items-center"
                >
                  <CheckCircle className="h-4 w-4 mr-1.5" />
                  Close Incident Outage / إغلاق الحادثة وحلها بنجاح
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
