/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Asset {
  id: string;
  name: string;
  type: 'Software' | 'Hardware' | 'Data' | 'Network' | 'Physical';
  value: 'Low' | 'Medium' | 'High' | 'Critical';
  location: string;
  owner: string;
  ipAddress?: string;
  description: string;
}

export interface Risk {
  id: string;
  name: string;
  assetId: string;
  likelihood: 'Low' | 'Medium' | 'High' | 'Critical';
  impact: 'Low' | 'Medium' | 'High' | 'Critical';
  level: 'Low' | 'Medium' | 'High' | 'Critical';
  threatSource: string;
  mitigation: string;
  status: 'Identified' | 'Mitigated' | 'Monitoring';
}

export interface Incident {
  id: string;
  date: string;
  time: string;
  description: string;
  assetId: string;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  status: 'Open' | 'In Progress' | 'Closed';
  reportedBy: string;
  resolution?: string;
}

export interface UserRole {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'IT Staff' | 'Security Auditor';
  department: string;
  lastActive: string;
}

export const INITIAL_ASSETS: Asset[] = [
  {
    id: 'ast-101',
    name: 'Student Information System (SIS)',
    type: 'Software',
    value: 'Critical',
    location: 'Cloud Server (Main)',
    owner: 'Registrar IT Department',
    ipAddress: '10.140.23.4',
    description: 'Houses all academic records, grades, enrollment logs, and personal details of 12,000+ technical college students.'
  },
  {
    id: 'ast-102',
    name: 'Campus Backbone Cisco Switch',
    type: 'Network',
    value: 'High',
    location: 'Main Server Room (Bldg A)',
    owner: 'Network Operations',
    ipAddress: '192.168.1.1',
    description: 'Primary core switch routing entire campus intra-traffic, wireless access points, and external trunk links.'
  },
  {
    id: 'ast-103',
    name: 'College Active Directory Domain Controller',
    type: 'Software',
    value: 'Critical',
    location: 'On-Premise Server Rack 2',
    owner: 'Systems Administration',
    ipAddress: '10.140.10.2',
    description: 'Manages authorization, accounts, single sign-on certificates, and computer profiles for all faculty and college workstations.'
  },
  {
    id: 'ast-104',
    name: 'College Financial Database',
    type: 'Data',
    value: 'Critical',
    location: 'Secure DB Cluster (Encrypted)',
    owner: 'Business & Finance Office',
    ipAddress: '10.140.10.8',
    description: 'Contains financial logs, state grant records, vendor transaction records, and student payment information.'
  },
  {
    id: 'ast-105',
    name: 'Learning Management System (Blackboard)',
    type: 'Software',
    value: 'High',
    location: 'AWS Cloud Instance',
    owner: 'Academic Affairs',
    ipAddress: '3.122.90.15',
    description: 'SaaS portal hosted in cloud for student course resources, online exams, homework submission, and discussion boards.'
  },
  {
    id: 'ast-106',
    name: 'Faculty Desk Workstations (140 Units)',
    type: 'Hardware',
    value: 'Medium',
    location: 'Academic Offices (Bldgs B & C)',
    owner: 'Desktop Support Techs',
    ipAddress: '10.140.40.x - Range',
    description: 'Faculty laptops and standard iMac/Windows computer terminals allocated for academic preparations.'
  },
  {
    id: 'ast-107',
    name: 'Engineering Lab CAD Workstations',
    type: 'Hardware',
    value: 'Medium',
    location: 'Mechanical Lab (Room 304)',
    owner: 'Lab Coordinator',
    ipAddress: '10.140.50.21',
    description: 'High-performance workstations equipped with GPU and CAD software for student design classes.'
  },
  {
    id: 'ast-108',
    name: 'College Public Web Portal (srams-college.edu)',
    type: 'Software',
    value: 'High',
    location: 'DMZ Security Zone Network',
    owner: 'Webmaster Division',
    ipAddress: '185.22.40.12',
    description: 'College landing page displaying courses, public relations documents, admissions forms, and announcements.'
  }
];

export const INITIAL_RISKS: Risk[] = [
  {
    id: 'rsk-201',
    name: 'Credential Phishing Attacks targeting Lecturers',
    assetId: 'ast-103',
    likelihood: 'High',
    impact: 'Critical',
    level: 'Critical',
    threatSource: 'External Social Engineering Campaign',
    mitigation: 'Implement mandatory Multi-Factor Authentication (MFA) and host monthly anti-phishing simulations.',
    status: 'Monitoring'
  },
  {
    id: 'rsk-202',
    name: 'Ransomware Infection via Lab Terminals',
    assetId: 'ast-107',
    likelihood: 'Medium',
    impact: 'High',
    level: 'High',
    threatSource: 'Insecure USB usage or unauthorized student downloads',
    mitigation: 'Implement deep-freeze configuration on lab PCs, block USB mass-storage via GPO rules.',
    status: 'Identified'
  },
  {
    id: 'rsk-203',
    name: 'SQL Injection on Admissions Gateway DB',
    assetId: 'ast-101',
    likelihood: 'Medium',
    impact: 'Critical',
    level: 'High',
    threatSource: 'Web vulnerability exploitation by malicious actors',
    mitigation: 'Web Application Firewall (WAF) provisioning, parameterized queries, and quarterly vulnerability scanning.',
    status: 'Mitigated'
  },
  {
    id: 'rsk-204',
    name: 'DDoS Attack disrupting online mid-terms',
    assetId: 'ast-105',
    likelihood: 'Low',
    impact: 'High',
    level: 'Medium',
    threatSource: 'Script kiddie actors or botnets targeting exams',
    mitigation: 'Configured Cloudflare Advanced DDoS Shield and routed all LMS DNS through proxy caching.',
    status: 'Mitigated'
  },
  {
    id: 'rsk-205',
    name: 'Unpatched Apache server vulnerability',
    assetId: 'ast-108',
    likelihood: 'High',
    impact: 'Medium',
    level: 'High',
    threatSource: 'Automated internet crawlers mapping exploits',
    mitigation: 'Scheduled security patch updates; setup automated alert trigger when service version falls out of date.',
    status: 'Monitoring'
  },
  {
    id: 'rsk-206',
    name: 'Power Grid failure in Server Room Server Rack',
    assetId: 'ast-102',
    likelihood: 'Low',
    impact: 'High',
    level: 'Medium',
    threatSource: 'Municipal utility outage or heavy thunder weather',
    mitigation: 'Redundant UPS batteries with 45 minutes bypass, diesel backup generator fully serviced.',
    status: 'Mitigated'
  }
];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'inc-301',
    date: '2026-05-20',
    time: '08:42',
    description: 'Bulk phishing emails flagged by faculty members mimicking dean notification to reset password.',
    assetId: 'ast-103',
    severity: 'High',
    status: 'Closed',
    reportedBy: 'Dr. Hussain Al-Marri',
    resolution: 'Suspicious domain blocked on network gateway; forced password reset on 3 compromised credential records.'
  },
  {
    id: 'inc-302',
    date: '2026-05-21',
    time: '14:15',
    description: 'Unauthorized port scanning traffic detected originating from Student CAD Workstations.',
    assetId: 'ast-107',
    severity: 'Medium',
    status: 'In Progress',
    reportedBy: 'Intrusion Detection System',
    resolution: 'Isolated CAD workstation MAC on vlan 50 to prevent further internal network probing; analyzing logs.'
  },
  {
    id: 'inc-303',
    date: '2026-05-22',
    time: '11:05',
    description: 'High CPU threshold exceeded alert on SIS application pool, causing slow enrollment page loads.',
    assetId: 'ast-101',
    severity: 'High',
    status: 'In Progress',
    reportedBy: 'Automated Nagios Monitoring',
    resolution: 'SRAMS administrators cleared dormant IIS connections and added dynamic bandwidth throttling.'
  },
  {
    id: 'inc-304',
    date: '2026-05-18',
    time: '19:30',
    description: 'Misconfigured public file drawer allowed brief anonymous download of campus layout PDF.',
    assetId: 'ast-108',
    severity: 'Low',
    status: 'Closed',
    reportedBy: 'External Security Researcher',
    resolution: 'Permissions updated to Private on S3 bucket and credentials revoked. Confirmed no sensitive data was leaked.'
  }
];

export const INITIAL_ROLES: UserRole[] = [
  {
    id: 'usr-401',
    name: 'Yaser Al-Shahrani',
    email: 'y.shahrani@college.edu',
    role: 'Admin',
    department: 'Cybersecurity & IT Infrastructure',
    lastActive: 'Active 2 mins ago'
  },
  {
    id: 'usr-402',
    name: 'Sara bin Al-Sayed',
    email: 'sara.sayed@college.edu',
    role: 'IT Staff',
    department: 'Network Services Group',
    lastActive: 'Active 12 mins ago'
  },
  {
    id: 'usr-403',
    name: 'Eng. Khalid bin Omar',
    email: 'khalid.omar@college.edu',
    role: 'IT Staff',
    department: 'Technical Desktop Operations',
    lastActive: 'Active 3 hours ago'
  },
  {
    id: 'usr-404',
    name: 'Dr. Fahad Al-Qahtani',
    email: 'fahad.q@college.edu',
    role: 'Security Auditor',
    department: 'External Academic Quality Council',
    lastActive: 'Active 2 days ago'
  }
];

export function calculateRiskLevel(likelihood: string, impact: string): 'Low' | 'Medium' | 'High' | 'Critical' {
  const map: Record<string, number> = {
    'Low': 1,
    'Medium': 2,
    'High': 3,
    'Critical': 4
  };
  
  const lVal = map[likelihood] || 1;
  const iVal = map[impact] || 1;
  const score = lVal * iVal;
  
  if (score <= 2) return 'Low';
  if (score <= 5) return 'Medium';
  if (score <= 9) return 'High';
  return 'Critical';
}
