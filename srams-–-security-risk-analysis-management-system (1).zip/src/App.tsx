/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Asset,
  Risk,
  Incident,
  UserRole,
  INITIAL_ASSETS,
  INITIAL_RISKS,
  INITIAL_INCIDENTS,
  INITIAL_ROLES
} from './types';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import DashboardHome from './components/DashboardHome';
import AssetManager from './components/AssetManager';
import RiskManager from './components/RiskManager';
import IncidentManager from './components/IncidentManager';
import Analytics from './components/Analytics';
import SettingsPage from './components/Settings';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('dashboard');

  // Unified global client-side State with secure client-side localStorage fallback (100% Free & Persistent)
  const [assets, setAssets] = useState<Asset[]>(() => {
    try {
      const saved = localStorage.getItem('srams_assets');
      return saved ? JSON.parse(saved) : INITIAL_ASSETS;
    } catch {
      return INITIAL_ASSETS;
    }
  });

  const [risks, setRisks] = useState<Risk[]>(() => {
    try {
      const saved = localStorage.getItem('srams_risks');
      return saved ? JSON.parse(saved) : INITIAL_RISKS;
    } catch {
      return INITIAL_RISKS;
    }
  });

  const [incidents, setIncidents] = useState<Incident[]>(() => {
    try {
      const saved = localStorage.getItem('srams_incidents');
      return saved ? JSON.parse(saved) : INITIAL_INCIDENTS;
    } catch {
      return INITIAL_INCIDENTS;
    }
  });

  const [roles, setRoles] = useState<UserRole[]>(() => {
    try {
      const saved = localStorage.getItem('srams_roles');
      return saved ? JSON.parse(saved) : INITIAL_ROLES;
    } catch {
      return INITIAL_ROLES;
    }
  });

  // Automatically sync variables into client local storage database
  React.useEffect(() => {
    localStorage.setItem('srams_assets', JSON.stringify(assets));
  }, [assets]);

  React.useEffect(() => {
    localStorage.setItem('srams_risks', JSON.stringify(risks));
  }, [risks]);

  React.useEffect(() => {
    localStorage.setItem('srams_incidents', JSON.stringify(incidents));
  }, [incidents]);

  React.useEffect(() => {
    localStorage.setItem('srams_roles', JSON.stringify(roles));
  }, [roles]);

  // Asset action handlers
  const handleAddAsset = (newAsset: Asset) => {
    setAssets((prev) => [newAsset, ...prev]);
  };

  const handleEditAsset = (updatedAsset: Asset) => {
    setAssets((prev) => prev.map((a) => (a.id === updatedAsset.id ? updatedAsset : a)));
  };

  const handleDeleteAsset = (id: string) => {
    setAssets((prev) => prev.filter((a) => a.id !== id));
    // Cascade delete associated risks for structural consistency
    setRisks((prev) => prev.filter((r) => r.assetId !== id));
    // Cascade update incidents asset references
    setIncidents((prev) => prev.map((i) => i.assetId === id ? { ...i, assetId: 'Deleted Asset ID' } : i));
  };

  // Risk action handlers
  const handleAddRisk = (newRisk: Risk) => {
    setRisks((prev) => [newRisk, ...prev]);
  };

  const handleEditRisk = (updatedRisk: Risk) => {
    setRisks((prev) => prev.map((r) => (r.id === updatedRisk.id ? updatedRisk : r)));
  };

  const handleDeleteRisk = (id: string) => {
    setRisks((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateRiskStatus = (riskId: string, status: Risk['status']) => {
    setRisks((prev) =>
      prev.map((r) => (r.id === riskId ? { ...r, status } : r))
    );
  };

  // Incident action handlers
  const handleAddIncident = (newIncident: Incident) => {
    setIncidents((prev) => [newIncident, ...prev]);
  };

  const handleEditIncident = (updatedIncident: Incident) => {
    setIncidents((prev) => prev.map((i) => (i.id === updatedIncident.id ? updatedIncident : i)));
  };

  const handleDeleteIncident = (id: string) => {
    setIncidents((prev) => prev.filter((i) => i.id !== id));
  };

  const handleUpdateIncidentStatus = (id: string, status: Incident['status'], resolution?: string) => {
    setIncidents((prev) =>
      prev.map((i) =>
        i.id === id
          ? {
              ...i,
              status,
              resolution: resolution !== undefined ? resolution : i.resolution
            }
          : i
      )
    );
  };

  // Personnel settings actions
  const handleAddUser = (newUser: UserRole) => {
    setRoles((prev) => [...prev, newUser]);
  };

  const handleEditUser = (updatedUser: UserRole) => {
    setRoles((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
  };

  const handleDeleteUser = (id: string) => {
    setRoles((prev) => prev.filter((u) => u.id !== id));
  };

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Navigator callback
  const handleNavigate = (view: string) => {
    setCurrentView(view);
    setIsSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased">
      {/* Dynamic top-bar */}
      <Navbar
        assets={assets}
        risks={risks}
        incidents={incidents}
        onNavigate={handleNavigate}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Structural Layout */}
      <div className="flex flex-1 pt-16">
        {/* Mobile Sidebar overlay backdrop */}
        {isSidebarOpen && (
          <div
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-20 md:hidden"
          />
        )}

        {/* Persistent left Nav sidebar */}
        <Sidebar
          currentView={currentView}
          onNavigate={handleNavigate}
          assetsCount={assets.length}
          risksCount={risks.filter(r => r.status !== 'Mitigated').length}
          incidentsCount={incidents.filter(i => i.status !== 'Closed').length}
          isSidebarOpen={isSidebarOpen}
          onCloseSidebar={() => setIsSidebarOpen(false)}
        />

        {/* Dynamic content rendering frame */}
        <main className="flex-1 md:ml-64 ml-0 p-4 md:p-8 relative max-w-7xl mx-auto w-full transition-all duration-300">
          {currentView === 'dashboard' && (
            <DashboardHome
              assets={assets}
              risks={risks}
              incidents={incidents}
              onNavigate={handleNavigate}
              onUpdateRiskStatus={handleUpdateRiskStatus}
            />
          )}

          {currentView === 'asset' && (
            <AssetManager
              assets={assets}
              onAddAsset={handleAddAsset}
              onEditAsset={handleEditAsset}
              onDeleteAsset={handleDeleteAsset}
              onNavigateToRisk={() => handleNavigate('risk')}
            />
          )}

          {currentView === 'risk' && (
            <RiskManager
              risks={risks}
              assets={assets}
              onAddRisk={handleAddRisk}
              onEditRisk={handleEditRisk}
              onDeleteRisk={handleDeleteRisk}
              onUpdateRiskStatus={handleUpdateRiskStatus}
            />
          )}

          {currentView === 'incident' && (
            <IncidentManager
              incidents={incidents}
              assets={assets}
              onAddIncident={handleAddIncident}
              onEditIncident={handleEditIncident}
              onDeleteIncident={handleDeleteIncident}
              onUpdateIncidentStatus={handleUpdateIncidentStatus}
            />
          )}

          {currentView === 'analytics' && (
            <Analytics
              assets={assets}
              risks={risks}
              incidents={incidents}
            />
          )}

          {currentView === 'settings' && (
            <SettingsPage
              roles={roles}
              onAddUser={handleAddUser}
              onEditUser={handleEditUser}
              onDeleteUser={handleDeleteUser}
            />
          )}
        </main>
      </div>
    </div>
  );
}
